

<?php $__env->startSection('content'); ?>
<h1>Les posts:</h1>

<?php $__currentLoopData = $_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('post.show', ['id'=>$post->id])); ?>"><h4>post <?php echo e($post->id); ?> : </h4></a>
<br>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\DEV\projets\laravel\resources\views/post.blade.php ENDPATH**/ ?>