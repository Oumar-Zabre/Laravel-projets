<?php

namespace App\Http\Controllers;
use App\Models\post;
use Illuminate\Http\Request;

class PostControlleur extends Controller
{
    public function index(){

    	return view('welcome');
    }




public function post()
{
 $_posts = post::all();

 return view('post',compact('_posts'));


}



    public function show($id){
       
       $posts = Post::find($id);

       return view('show',['_post'=>$posts]);
   
    }




    public function contact(){

    	return view('contact');
    }
}
