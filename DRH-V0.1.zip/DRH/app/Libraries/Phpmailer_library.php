<?php
class Phpmailer_library
{
    public function __construct()
    {
        log_message('Debug', 'PHPMailer class is loaded.');
    }

    public function load(){
        // Include PHPMailer library files
        require_once APPPATH.'third_party/phpmailer/src/Exception.php';
        require_once(APPPATH.'third_party/phpmailer/src/PHPMailer.php');
        require_once(APPPATH.'third_party/phpmailer/src/SMTP.php');

        $objMail = new PHPMailer\PHPMailer\PHPMailer();
        //var_dump($objMail);
        
        return $objMail;
    }

    public static function sendPhpMail($displayName = "",$message, $to, $subject, $file= null){
        $CI =& get_instance();
        $mail = $CI->phpmailer_library->load();

        // SMTP configuration
        $mail->isSMTP();
        $mail->Host     = 'smtp.hostinger.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'no_reply@databases.humanprojectgroup.com';
        $mail->Password = 'zi4LeCl0S@05hbe';
        $mail->SMTPSecure = 'ssl';
        $mail->CharSet = 'UTF-8';
        $mail->Port     = 465;

        $mail->setFrom(Tools::getFrom(), $displayName);
        
        // Add a recipient
        $mail->addAddress($to);

        // Add cc or bcc 
        //$mail->addCC('cc@example.com');
        //$mail->addBCC('bcc@example.com');

        // Email subject
        $mail->Subject = $subject;

        // Set email format to HTML
        $mail->isHTML(true);

        // Email body content
        $mail->Body = $message;

        // Send email
        $ret = $mail->send();
        if(!$ret){
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
            echo 'Message has been sent';
        }
        return $ret;
    }
}