@extends('layout.app')
@section('content')

<strong>Contactez-Nous</strong>

@endsection