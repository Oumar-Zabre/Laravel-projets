
<?php $__env->startSection('content'); ?>

<strong>Contactez-Nous</strong>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\DEV\projets\laravel\resources\views/contact.blade.php ENDPATH**/ ?>