<?php
namespace App\Filters;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
class AuthMiddleware implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
  // Obtenir le service de session
        $session = Services::session();
        // Vérifier si l'utilisateur est authentifié en vérifiant la session
        if (empty($session->iduser) || $session->idroleuser == 2 ) {
            // L'utilisateur n'est pas authentifié, nous le redirigeons vers la page de connexion
            $response = service('response');
            return redirect()->to('/login');
        }
        // L'utilisateur est authentifié, nous laissons la requête continuer
        return $request;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Vous pouvez effectuer des actions après que la route ait été traitée.
    }
}
