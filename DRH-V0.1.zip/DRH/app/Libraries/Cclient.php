<?php
defined('BASEPATH') OR exit('No direct script access allowed');

include_once 'BaseController.php';

class Cclient extends BaseController {

	public function __construct(){
		parent::__construct();
		// $options = array(
		// 	'idFromClient' => 1,
		// 	'recipientEmail' => 'email@email.com',
		// 	'recipientFirstName' => 'Nom',
		// 	'recipientLastName' => 'Prenom',
		// 	'destinataire' => '+22676552281',
		// 	'otp' => '1643343',
		// 	'amount' => 100,
		// 	'recipientNumber' => '+22676552281',
		// 	"serviceCode" => '34351841',
		// );

		// $parametres = [
  //           "idFromClient" => time(), //id que tu vas générer
  //           "recipientEmail" => 'email@email.com', 
  //           "recipientFirstName" => "COMPAORE",
  //           "recipientLastName" => "MOUSTAPHA",
  //           "destinataire" => "+22676552281", //Ton numéro
  //           "otp" => "370020",
		// 	"amount" => "100",
		// 	"recipientNumber" => "76552281", //Ton numéro
		// 	"serviceCode" => "BF_PAIEMENTMARCHAND_OM_TP",
  //       ];

		// $res = PaiementTools::createTransaction($parametres);
		// var_dump($res);die();
		// var_dump($this->Client->findPk(11));die();
		// var_dump(date_diff(date_create('2019-08-25 22:30:23'),date_create('2019-08-23 12:00:23')));die();
		// $res = SmsTools::sendSmsbusPOST('0022676552281','XX12345');
		// echo 'res = '.$res;die();
		// $_SESSION['idclient'] = 1;
		// $_SESSION['name'] = 'Client 1';
		// $_SESSION['Type_user'] = 'Client';
		// $_SESSION['idutilisateur'] = 1;

		$uri = explode(base_url().'index.php/', current_url())[1];
		$uri = str_replace('/', '_', $uri);
		//die();
		if (empty($this->session->userdata('idutilisateur')) || $this->session->userdata('Type_user')!="Client" || empty($this->session->userdata('idclient'))) {
		    redirect(base_url().'Usersession/client?uri='.$uri); die();
		}
		
		//après la connexion, recharger les données du panier
		if (empty($_SESSION['duree']) || empty($_SESSION['total']) || empty($_SESSION['nbitems'])) {
			$com = $this->Params->findPk(2)->getValparam();
			$rs = Tools::last($this->Reservation->where('idclient = '.$this->session->userdata('idclient').' AND idstatutreservation = 1 '));
				$_SESSION['duree'] = 0;
				$_SESSION['total'] = 0;
				$_SESSION['nbitems'] = 0;
			if (!empty($rs)) {
				$tduree = date_diff(date_create($rs->getDateretourprevue()), date_create($rs->getDatedepart()));
				$duree = $tduree->format('%a');
				if ($tduree->h >0 || $tduree->i >0) {
					$duree++; // au cas où l'heure de retour dépasse l'heure de départ, ajouter 1e journée à la période de la réservation 
				}
				$_SESSION['duree'] = $duree;
				foreach ($rs->getReservationvoitures() as $rsv) {
					$_SESSION['nbitems']++;
					$_SESSION['total'] += $this->session->userdata('duree') * $rsv->getPrixjournalier() * ($com+1);
					//ajout du cout de l'option de la reservation si il y en a
					if ($rsv->getOptionreservation()!=null) {
						$_SESSION['total'] +=  $this->session->userdata('duree') * $rsv->getOptionreservation()->getPrixjournalier();
					}
				}
			}
		}
		$this->config->set_item('language', $_SESSION['language']);
		$this->lang->load('accueil', $_SESSION['language']);
  	}
		

	public function index(){
		$hdata['page_title']='Accueil';
		$data['page_title']=$hdata['page_title'];
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/index',$data);
		$this->load->view('layout/footer');
	}

	public function reservervoiture($idv = null){
		$com = $this->Params->findPk(2)->getValparam();
		if (!empty($_POST) && ( isset($_POST['btn-add-car'])) || isset($_POST['btn-go-pay']) ) {
			// var_dump($_POST);die();
			//Vérifier si le client a confirmer son numero de tel
			$user = $this->Utilisateur->findPk($this->session->userdata('idutilisateur'));
			if(empty($user) || $user->getIdstatutcompte()!=4){
				//redirect(base_url().'cclient/index');
				echo '3';die();
			}
			$idrs = null;
			$v = $this->Voiture->findPk($this->input->post('idvoiture'));
			if (isset($_POST['idreservation'])) {
				$idrs = $this->input->post('idreservation');
			}else{
				$rs = new Reservation();
				$rs->setDatereservation(date('Y-m-d H:i:s'));
				$rs->setIdstatutreservation(1);
				$rs->setIdclient($this->session->userdata('idclient'));
				if (!empty($this->input->post('datedepart'))) {
					$rs->setDatedepart(Tools::toMySqlDateformat($this->input->post('datedepart'), true));
				}
				if (!empty($this->input->post('dateretourprevue'))) {
					$rs->setDateretourprevue(Tools::toMySqlDateformat($this->input->post('dateretourprevue'), true));
				}
				$rs->setIdstatutreservation(1);
				$rs->setLieudepart($this->input->post('lieudepart'));
				$rs->setLieuarrive($this->input->post('lieuarrive'));
				$idrs = $rs->save();
				$tduree = date_diff(date_create($rs->getDateretourprevue()), date_create($rs->getDatedepart()));
				$duree = $tduree->format('%a');
				if ($tduree->h >0 || $tduree->i >0) {
					$duree++; // au cas où l'heure de retour dépasse l'heure de départ, ajouter 1e journée à la période de la réservation 
				}
				$_SESSION['duree'] = $duree;
			}
			// var_dump($idrs);die();
			//Vérifier si la reservation contient déjà cette voiture
			$rsv = $this->Reservationvoiture->where('idreservation = '.$idrs.' AND idvoiture = '.$v->getIdvoiture());
			if (count($rsv)==0){
				$rsv = new Reservationvoiture();
				$rsv->setIdreservation($idrs);
				$v= $this->Voiture->findPk($this->input->post('idvoiture'));
				$rsv->setIdvoiture($v->getIdvoiture());
				if (!empty($_POST['idoptionreservation'])) {
					$rsv->setIdoptionreservation($this->input->post('idoptionreservation'));
				}
				$rsv->setKmdepart($v->getKm());
				$rsv->setPrixjournalier(Tools::last($v->getEtatvoitures())->getPrixjournalier());
				$rsv->setIdetat(Tools::last($v->getEtatvoitures())->getIdetat());
				$rsv->setIdstatutreservation(1); 
				$rsv->setOtpcloture(Tools::getRandomNumber());
				$rsv->save();
				if (empty($this->session->userdata('total'))) {
					$_SESSION['nbitems']=1;
				} else {
					$_SESSION['nbitems']++;
				}
				if (empty($this->session->userdata('total'))) {
					$_SESSION['total'] = $this->session->userdata('duree') * $rsv->getPrixjournalier() * ($com+1);
				}else{
					$_SESSION['total'] += $this->session->userdata('duree') * $rsv->getPrixjournalier() * ($com+1);
				}
				//ajout du prix de l'option de reservation
				if (!empty($_POST['idoptionreservation'])) {
					$_SESSION['total'] += $this->session->userdata('duree') * $rsv->getOptionreservation()->getPrixjournalier();
				}
				$ret = Tools::notifReservationToProp($v->getProprietaire()->getMail1(), $rsv, $v->getProprietaire()->getTel1());
				// var_dump($ret);die();
				// echo $this->input->post('btn-add-car');die();
			}
			if (isset($_POST['btn-add-car'])) {
				echo '1';die();
			}
			echo '2';die();
			// redirect(base_url().'cclient/panier');
		}
		$user = $this->Utilisateur->findPk($this->session->userdata('idutilisateur'));
		if(empty($user) || $user->getIdstatutcompte()!=4){
			redirect(base_url().'cclient/profil');die();
		}
		$v = $this->Voiture->findPk($idv);
		if (empty($v)) {
			redirect(base_url().'/cclient/index');die();
		}
		$rs=null;
		$lrs = $this->Reservation->where('idclient = '.$this->session->userdata('idclient'). ' AND idstatutreservation = 1');
		if (count($lrs)==0) {
			$rs = new Reservation();
		}else{
			$rs = Tools::last($lrs);
		}
		//var_dump($rs);die();
		$data['v'] = $v;
		$data['rs'] = $rs;
		$data['loptionsreservation'] = $this->Optionreservation->findAll();
		$data['prix'] = Tools::last($v->getEtatvoitures())->getPrixjournalier()*(1+$this->Params->findPk(2)->getValparam());
		$hdata['page_title']='Réserver la voiture';
		$data['page_title']=$hdata['page_title'];
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/reservervoiture',$data);
		$this->load->view('layout/footer');	
	}

	public function reservations(){
		$idc = $this->session->userdata('idclient');
		if (empty($idc)) {
			redirect(base_url().'usersession/logout/');die();
		}
		$data['msg'] = '';
        if (!empty($_GET) && isset($_GET['code'])) {
            $data['msg'] = '<div class="alert alert-success">Modification enrégistrée avec succès</div>';
        }
		$data['lst_reservation_valid'] = $this->Reservation->where('idclient = '.$idc.' AND (idstatutreservation = 2 or idstatutreservation = 3) ' );
		$data['lst_reservation_returned'] = $this->Reservation->where('idclient = '.$idc.' AND (idstatutreservation = 4 or idstatutreservation = 5 or idstatutreservation = 6) ');
		$data['lst_reservation_ended'] = $this->Reservation->where('idclient = '.$idc.' AND (idstatutreservation = 7 or idstatutreservation = 8) ' );
		$data['lst_reservation_canceled'] = $this->Reservation->where('idclient = '.$idc.' AND (idstatutreservation = 4 or idstatutreservation = 5 or idstatutreservation = 6) ' );
		$hdata['page_title']='Mes réservations';
		$data['page_title']=$hdata['page_title'];
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/reservations',$data);
		$this->load->view('layout/footer');	
	}

	public function panier(){
		$idc = $this->session->userdata('idclient');
		$data['panier'] = Tools::last($this->Reservation->where('idclient = '.$idc.' AND idstatutreservation = 1'));
		// $data['laststr'] = $this->Model->query("SELECT del from reservation where idclient = $idc order by idreservation desc limit 1");
		$data['justdel'] = false;
		if (!empty($_GET) && isset($_GET['justdel']) && $_GET['justdel']==1) {
			$data['justdel'] = true;
		}
		// var_dump($data['laststr'][0]->del);die();
		$data['com'] = $this->Params->findPk(2)->getValparam();
		$data['loptionsreservation'] = $this->Optionreservation->findAll();
		$lidop = null;
		if (!empty($data['panier']) && !empty($data['panier']->getReservationvoitures())) {
			$opt = $this->Optionreservation->findPk($data['panier']->getReservationvoitures()[0]->getIdoptionreservation());
			if (!empty($opt)) {
				$lidop = $opt->getIdoptionreservation();
			}
		}
		$data['lidop'] = $lidop;
		$hdata['page_title']='Mon panier';
		$data['page_title']=$hdata['page_title'];
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/panier',$data);
		$this->load->view('layout/footer');	
	}

	public function cancelrv(){
		$idrv = (!empty($_POST['id'])) ? $this->input->post('id') : 0 ;
		$rv = $this->Reservationvoiture->findPk($idrv);
		if (empty($rv)) {
			echo 'n';die();
		}
		$rv->setDel(1);
		$rv->save();
		$p=$rv->getVoiture()->getProprietaire();
		Tools::notifCancReservationToProp($p->getMail1(), $rv, $p->getTel1());
		//diminution du total de la réservation
		$_SESSION['total'] -= $this->session->userdata('duree') * $rv->getPrixjournalier();
		$_SESSION['nbitems'] --;
		//Verifier si le panier est vide ou pas. Si oui, le supprimer
		$panier = $rv->getReservation();
		if (count($panier->getReservationvoitures())==0) {
			$panier->setDel(1);
			$panier->save();
			echo '2';
			return;
		}
		echo '1';
		return;
	}

	public function cancelpanier()
	{
		$panier = $this->Reservation->where('idclient = '.$this->session->userdata('idclient').' AND idstatutreservation = 1');
		if (!empty($panier)) {
			$panier = Tools::last($panier);
			$panier->clearReservationvoitures();
			$panier->setDel(1);
			$panier->save();
			unset($_SESSION['duree']);
			unset($_SESSION['nbitems']);
			unset($_SESSION['total']);
			echo '1';die();
		}
		//diminution du total de la réservation
		echo 'n';
		die();
	}

	public function cancelreservation($idr = null){
		if (!empty($_POST) && isset($_POST['btnconfcanc'])) {
			$idr = $this->input->post('idr');
			$rs = $this->Reservation->findPk($idr);
			if (empty($rs)) {
				redirect(base_url().'cclient/reservations/?code=2');die();
			}
			$rs->setIdstatutreservation(4);
			$rs->save();
			foreach ($rs->getReservationvoitures() as $rsv) {
				$rsv->setIdstatutreservation(4);
				$p = $rsv->getVoiture()->getProprietaire();
				Tools::notifCancReservationToProp($p->getMail1(), $rsv, $p->getTel1());

			}
			redirect(base_url().'cclient/reservations/?code=1');die();
		}
		$rs = $this->Reservation->findPk($idr);
		if (empty($rs)) {
			redirect(base_url().'cclient/reservations');die();
		}
		$data['rs'] = $rs;
		$hdata['page_title']='Annuler réservation';
		$data['page_title']="Voulez-vous vraiment annuler cette réservation?";
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/cancelreservation',$data);
		$this->load->view('layout/footer');	
	}

	public function retour($idr = null){
		
		if (!empty($_POST) && isset($_POST['btnconfret']) && isset($_POST['idr'])) {
			// var_dump($_POST);die();
			$idr = $this->input->post('idr');
			$rs = $this->Reservation->findPk($idr);
			if (!empty($_POST['dateretour'])) {
				$rs->setDateretourreel(Tools::toMySqlDateformat($_POST['dateretour'], false));
				$rs->setDateenregretour(date('Y-m-d H:i:s'));
			}
			$rs->setCommentaire($this->input->post('commetaire'));
			$rs->setIdstatutreservation(7);
			$rs->save();
			$lsrv = $rs->getReservationvoitures();
			foreach ($lsrv as $rsv) {
				if (!empty($_POST['note-voiture-'.$rsv->getIdreservationvoiture()])) {
					$noteV = $this->input->post('note-voiture-'.$rsv->getIdreservationvoiture());
					$noteP = $this->input->post('note-prop-'.$rsv->getIdreservationvoiture());
					$rsv->setNoteproprietaire($noteP);
					$rsv->setNotevoiture($noteV);
					$rsv->setCommentairevoiture($this->input->post('commentairevoiture-'.$rsv->getIdreservationvoiture()));
					$rsv->setCommentaireproprietaire($this->input->post('commentaireproprio-'.$rsv->getIdreservationvoiture()));
					$rsv->setIdstatutreservation(7);
					$rsv->save();
					$prop = $rsv->getVoiture()->getProprietaire();
					Tools::notifRetourToProp($prop->getMail1(), $rsv, $prop->getTel1());
				}
			}
			redirect(base_url().'cclient/reservations/?code=1');die();
		}
		$rs = $this->Reservation->findPk($idr);
		if (empty($rs)) {
			redirect(base_url().'cclient/retour');die();
		}
		$data['rs'] = $rs;
		$hdata['page_title']='enregistrer un retour';
		$data['page_title']="Voulez-vous enregistrer le retour de cette réservation?";
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/retour',$data);
		$this->load->view('layout/footer');	
	}

	public function checkout(){
		$idclient = $this->session->userdata('idclient');
		$client = $this->Client->findPk($idclient);
		if (empty($client)) {
			redirect(base_url().'cclient/index');die();
		}
		$data['com'] = $this->Params->findPk(2)->getValparam();
		$panier = Tools::last($this->Reservation->where('idclient = '.$this->session->userdata('idclient').' AND idstatutreservation = 1'));
		if (empty($panier)) {
			redirect(base_url().'cclient/profil');die();
		}
		if (!empty($_POST) && isset($_POST['btn-pay'])) {
			//var_dump($_POST);die();
			// $panier = Tools::last($this->Reservation->where('idclient = '.$this->session->userdata('idclient').' AND idstatutreservation = 1'));
			$user = $this->Utilisateur->findPk($this->session->userdata('idutilisateur'));
			if (empty($user)) {
				redirect(base_url());die();
			}		
			if (!empty($panier)) {
				$moyen = $this->input->post('idmoyenpaiement');
				if ($moyen == 5) {
					// var_dump($_POST);die();
					$returnURL = base_url().'cclient/paypalok';
					$cancelURL = base_url().'cclient/paypalcancel';
					$notifyURL = base_url().'welcome/paypalnotify';
					$product = array(
						'id'    => $panier->getIdreservation(),
						'name'  => 'Fasomobili Reservation du '.Tools::fromMySqlDateformat($panier->getDatereservation(), true),
						'price' => ($this->session->userdata('total')/655.957)
					);

					$userId = $this->session->userdata('idutilisateur');
					$this->paypal_lib->add_field('return', $returnURL);
					$this->paypal_lib->add_field('cancel_return', $cancelURL);
					$this->paypal_lib->add_field('notify_url', $notifyURL);
					$this->paypal_lib->add_field('item_name', $product['name']);
					$this->paypal_lib->add_field('custom', $userId);
					$this->paypal_lib->add_field('item_number', $product['id']);
					$this->paypal_lib->add_field('amount', $product['price']);

					$this->paypal_lib->paypal_auto_form();
					die();
				}else{
					$statut = 1;
					$paiement = new Paiement();
					$paiement->setDatepaiement(date('Y-m-d H:i:s'));
					$paiement->setMontantpaiement($this->session->userdata('total'));
					$paiement->setIdmoyenpaiement($moyen);
					$paiement->setOptverif($this->input->post('codeverif'));
					$paiement->setIdreservation($panier->getIdreservation());
					$idc = null;
					if ($moyen == 1) {
						$compteOM = new Compteom();
						$compteOM->setNumero($this->input->post('numborange'));
						$idc = $compteOM->save();
						$paiement->setIdcompteom($idc);
						$statut = Tools::checkPaiement($client, $this->input->post('numborange'), $paiement->getMontantpaiement(), $paiement->getOptverif());
					}
					if ($statut==1) {
						$paiement->setIdstatutpaiement(1);
					}else{
						$paiement->setIdstatutpaiement(2);
					}
					$paiement->save();
					$lrsv = array(); 
					if($statut==1){
						$panier->setIdstatutreservation(2);
						$lrsv = $panier->getReservationvoitures();
						foreach ($lrsv as $rsv) {
							$rsv->setIdstatutreservation(2);
							$rsv->save();
						}
						$panier->save();
						unset($_SESSION['duree']);
						unset($_SESSION['nbitems']);
						unset($_SESSION['total']);
					}
					$com= $this->Params->findPk(2)->getValparam();
					$email = $user->getNomutilisateur();
					$datereservation = $panier->getDatereservation();
					Tools::sendReservationNotif($email,$datereservation, $lrsv, $paiement, $com);
					// die();
					redirect(base_url().'cclient/afterreservation/'.$statut);die();
				}
			}
		}
		$data['lmoyenpaiement'] = $this->Moyenpaiement->findAll();
		$hdata['page_title']='Paiement de ma réservation';
		$data['page_title']=$hdata['page_title'];
		$data['client'] = $client;
		$data['panier'] = Tools::last($this->Reservation->where('idclient = '.$this->session->userdata('idclient').' AND idstatutreservation = 1'));
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/checkout',$data);
		$this->load->view('layout/footer');
	}

	public function paypalok(){
		$panier = Tools::last($this->Reservation->where('idclient = '.$this->session->userdata('idclient').' AND idstatutreservation = 1'));
		$paypal = new Paypal();
		$paypal->setPayerid($_REQUEST['payer_id']);
		$paypal->setPayeremail($_REQUEST['payer_email']);
		$paypal->setPayerstatus($_REQUEST['payer_status']);
		$paypal->setPayername($_REQUEST['last_name'].' '.$_REQUEST['first_name']);
		$paypal->setPaymentstatus($_REQUEST['payment_status']);
		$paypal->setPaymenttype($_REQUEST['payment_type']);
		$paypal->setPaymentdate($_REQUEST['payment_date']);
		$paypal->setReceiverid($_REQUEST['receiver_id']);
		$paypal->setBusiness($_REQUEST['business']);
		$paypal->setVerifysign($_REQUEST['verify_sign']);
		$paypal->setTxnid($_REQUEST['txn_id']);
		$paypal->save();
		if ($_REQUEST['payment_status']=='Completed') {
			$paiement = new Paiement();
			$paiement->setDatepaiement(date('Y-m-d H:i:s'));
			$paiement->setMontantpaiement($this->session->userdata('total'));
			$paiement->setIdmoyenpaiement(5);
			$paiement->setIdreservation($panier->getIdreservation());
			$idc = null;
			$paiement->setIdstatutpaiement(1);
			$paiement->save();
			$lrsv = array(); 
			$panier->setIdstatutreservation(2);
			$lrsv = $panier->getReservationvoitures();
			foreach ($lrsv as $rsv) {
				$rsv->setIdstatutreservation(2);
				$rsv->save();
			}
			$panier->save();
			unset($_SESSION['duree']);
			unset($_SESSION['nbitems']);
			unset($_SESSION['total']);
			redirect(base_url().'cclient/afterreservation/1');die();
		}
		redirect(base_url().'cclient/afterreservation/6');die();
		// echo 'ok<br>';
		// var_dump($_REQUEST);

	}

	public function paypalcancel(){
		// echo 'NonOK<br>';
		// var_dump($_REQUEST);
		redirect(base_url().'cclient/afterreservation/8');die();
	}

	public function paypalnotify(){
		echo 'Notif<br>';
		var_dump($_REQUEST);die();
	}

	public function editpanier(){
		//var_dump($_POST);
		if (!empty($_POST) && isset($_POST['id'])) {
			$panier = $this->Reservation->findPk($this->input->post('id'));
			if (!empty($panier)) {
				$panier->setDatedepart(Tools::toMySqlDateformat($this->input->post('datedepart'), true));
				$panier->setDateretourprevue(Tools::toMySqlDateformat($this->input->post('dateretourprevue'), true));
				$panier->setLieudepart($this->input->post('lieudepart'));
				$panier->setLieuarrive($this->input->post('lieuarrive'));
				$idop = $this->input->post('idoptionreservation');   
				$opt = $this->Optionreservation->findPk($idop);
				$panier->save();
				$tduree = date_diff(date_create($panier->getDateretourprevue()), date_create($panier->getDatedepart()));
				$duree = $tduree->format('%a');
				if ($tduree->h >0 || $tduree->i >0) {
					$duree++; // au cas où l'heure de retour dépasse l'heure de départ, ajouter 1e journée à la période de la réservation 
				}
				$com = $this->Params->findPk(2)->getValparam();
				$_SESSION['duree'] = $duree;
				$_SESSION['total'] = 0;
				foreach ($panier->getReservationvoitures() as $rsv) {
					$rsv->setIdoptionreservation($idop);
					$rsv->save();
					//Mise à jour du coût en fonction des prix des voitures
					$_SESSION['total'] += $this->session->userdata('duree') * $rsv->getPrixjournalier() * (1+$com);
					//Mise à jour du coût en fonction des options de réservation
					if (!empty($opt)) {
						$_SESSION['total'] += $this->session->userdata('duree') * $opt->getPrixjournalier();
					}
				}
				echo '1'; die();
			}
		}
		echo '-1';
		die();
	}

	public function afterreservation($statut){
		if ($statut == 1) {
			$hdata['page_title']='Validation du paiement de votre réservation';
			$data['msg']='<div class="alert alert-success">Votre mode de paiement a été pris en compte. Un récapitulatif vous sera envoyé par email . Merci.<br>L\'équipe Fasomobili </div>';
		}elseif($statut == 2){
			$hdata['page_title']='Erreur lors du paiement de votre réservation';
			$data['msg']='<div class="alert alert-danger">Le numero de telephone saisi est incorrecte. Merci.<br>L\'équipe Fasomobili </div>';
		}elseif($statut == 3){
			$hdata['page_title']='Erreur lors du paiement de votre réservation';
			$data['msg']='<div class="alert alert-danger">L\'operation de paiement a echoué. Veuillez vérifier le numero de téléphone, l\'OTP que vous avez reçu après le paiement et que le montant du paiement est égal au montant de la réservation. Merci.<br>L\'équipe Fasomobili </div>';
		}elseif($statut == 4){
			$hdata['page_title']='Erreur lors du paiement de votre réservation';
			$data['msg']='<div class="alert alert-danger">Cher client, l\'e OTP doit contenir 6 chiffres. Merci.<br>L\'équipe Fasomobili </div>';
		}elseif($statut == 5){
			$hdata['page_title']='Erreur lors du paiement de votre réservation';
			$data['msg']='<div class="alert alert-danger">Cher client, l\'e OTP utilise n\'existe pas. Merci.<br>L\'équipe Fasomobili </div>';
		}elseif($statut == 6){
			$hdata['page_title']='Erreur lors du paiement de votre réservation';
			$data['msg']='<div class="alert alert-danger">Votre paiement n\'a pas été accepté par Paypal. Bien vouloir recommencer. Merci.<br>L\'équipe Fasomobili </div>';
		}elseif($statut == 7){
			$hdata['page_title']='Erreur lors du paiement de votre réservation';
			$data['msg']='<div class="alert alert-danger">Ereur interne de Paypal. Bien vouloir réessayer plus tard. Merci.<br>L\'équipe Fasomobili</div>';
		}elseif($statut == 8){
			$hdata['page_title']='Annulation du paiement';
			$data['msg']='<div class="alert alert-info">Votre paiement a été annulé. Bien vouloir réessayer plus tard. Merci.<br>L\'équipe Fasomobili</div>';
		}else{
			$hdata['page_title']='Erreur lors du paiement de votre réservation';
			$data['msg']='<div class="alert alert-danger">Ereur interne de Orange Money. Bien vouloir réessayer plus tard. Merci.<br>L\'équipe Fasomobili </div>';
		}
		$data['page_title']=$hdata['page_title'];
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/afterreservation',$data);
		$this->load->view('layout/footer');
	}

	public function profil(){
		$client = $this->Client->findPk($this->session->userdata('idclient'));
		if (empty($client)) {
			redirect(base_url().'usersession/login/?code=7');die();
		}
		if (!empty($_FILES)) { //changement de photo de profil
			// var_dump($_FILES);die();
			$client = $this->Client->findPk($this->session->userdata('idclient'));
			$urlphoto = Tools::do_upload_file($_FILES,'public/userdata',array('png', 'jpeg', 'jpg'), 'photo_'.time(),'photo');
			if ($urlphoto!="cc1" && $urlphoto!="cc2") {
				$client->setPhoto($urlphoto);
			}
			$client->save();
			redirect(base_url().'cclient/profil');
			echo '1';die();
		}
		if (!empty($_POST) && isset($_POST['nom'])) { //changement des autres informations du profil
			// var_dump($_POST);die();
			$client = $this->Client->findPk($this->session->userdata('idclient'));
			if (!empty($this->input->post('idpays'))) {
				$iso = $this->input->post('idpays');
				$lp = $this->Pays->where('iso = '.$iso);
				if (count($lp)==1) {
					$client->setIdpays($lp[0]->getIdpays());
				}
			}
			$client->setNom($this->input->post('nom'));
			$client->setPrenom($this->input->post('prenom'));
			// $client->setMail1($this->input->post('email1'));
			$client->setTel1($this->input->post('tel1'));
			$client->setCivilite($this->input->post('civilite'));
			// $client->setTel2($this->input->post('tel2'));
			// $client->setMail2($this->input->post('email1'));
			$client->setNipCnib($this->input->post('nipcnib'));
			$client->setNumpermis($this->input->post('numpermis'));
			$client->setLieunais($this->input->post('lieunais'));
			$client->setVilleresidence($this->input->post('villeresidence'));
			$client->setNumpassport($this->input->post('numpassport'));
			$client->setAdresse($this->input->post('adresse'));
			if (!empty($this->input->post('datenais'))) {
				$client->setDatenais(Tools::toMySqlDateformat($this->input->post('datenais'), false));
			}else{
				$client->setDatenais(null);
			}
			if (!empty($this->input->post('dateetabpassport'))) {
				$client->setDateetabpassport(Tools::toMySqlDateformat($this->input->post('dateetabpassport'),false));
			}else{
				$client->setDateetabpassport(null);
			}
			$client->save();
			redirect(base_url().'cclient/profil');
			echo '2';die();
		}
		$data['lpays'] = $this->Pays->findAll();
		$data['client'] = $client;
		$hdata['page_title']='Mon profil';
		$data['page_title']=$hdata['page_title'];
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/profil',$data);
		$this->load->view('layout/footer');
	}

	public function modifdonnees(){
		$idc = $this->session->userdata('idclient');
		$client = $this->Client->findPk($idc);
		if(empty($client)){
			redirect(base_url().'usersession/logout');die();	
		}
		if (!empty($_POST) && isset($_POST['btnsave'])) {
			// var_dump($_POST);die();
			if (!empty($this->input->post('idpays'))) {
				$iso = $this->input->post('idpays');
				$lp = $this->Pays->where('iso = '.Tools::quote($iso));
				if (count($lp)==1) {
					$client->setIdpays($lp[0]->getIdpays());
				}
			}
			$usr = $client->getUtilisateur();
			$usr->setLang($this->input->post('lang'));
			$usr->save();
			$client->setNom($this->input->post('nom'));
			$client->setPrenom($this->input->post('prenom'));
			// $client->setMail1($this->input->post('email1'));
			$client->setTel1($this->input->post('tel1'));
			$client->setCivilite($this->input->post('civilite'));
			// $client->setTel2($this->input->post('tel2'));
			// $client->setMail2($this->input->post('email1'));
			$client->setNipCnib($this->input->post('nipcnib'));
			$client->setNumpermis($this->input->post('numpermis'));
			$client->setLieunais($this->input->post('lieunais'));
			$client->setVilleresidence($this->input->post('villeresidence'));
			$client->setNumpassport($this->input->post('numpassport'));
			$client->setAdresse($this->input->post('adresse'));
			if (!empty($this->input->post('datenais'))) {
				$client->setDatenais(Tools::toMySqlDateformat($this->input->post('datenais'), false));
			}else{
				$client->setDatenais(null);
			}
			if (!empty($this->input->post('dateetabpassport'))) {
				$client->setDateetabpassport(Tools::toMySqlDateformat($this->input->post('dateetabpassport'),false));
			}else{
				$client->setDateetabpassport(null);
			}
			$client->save();
			redirect(base_url().'cclient/profil');die();
		}
		$data['client'] = $client;
		$data['lpays'] = $this->Pays->findOrder('libpays', 'desc', -1);
		$hdata['page_title'] = "Modifier mes coordonnées";
		$data['page_title']=$hdata['page_title'];
		$this->load->view('layout/header',$hdata);
		$this->load->view('cclient/modifdonnees',$data);
		$this->load->view('layout/footer');
	}
}