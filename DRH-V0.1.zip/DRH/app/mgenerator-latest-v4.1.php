<?php 

	/*
	*	Auteur  : COMPAORE MOUSTAPHA
	*	URL     :	http://www.comptechnoafrique.com/demos/moustacompa
	*	Version : 3.0
	*   Update date : 16/02/2022 
	*/

	define('ENVIRONMENT', isset($_SERVER['CI_ENV']) ? $_SERVER['CI_ENV'] : 'development');
	
	$db['default'] = array(
		'port'	=> '5432',
		'hostname' => 'localhost',
		'username' => 'consultdbuser',
		'password' => 'consult@2024',
		'database' => 'db_gestpatrimoine',
		'dbdriver' => 'pgsql',		
	);

	$exclude_tab = array('created_by', 'updated_by', 'deleted_by');

	//include_once 'config/database.php';

	$modelPath = __DIR__.'/models';
	$entityPath = __DIR__.'/Entities';

	$driver=$db['default']['dbdriver'];
	$host=$db['default']['hostname'];
	$dbname=$db['default']['database'];
	$user=$db['default']['username'];
	$pass=$db['default']['password'];
	$port=$db['default']['port'];
	$connexion = new PDO($driver.':host='.$host.';dbname='.$dbname.';port='.$port,$user,$pass);

	if($connexion){
		echo 'Connected to DB.';
		$nbTables = 0;
		$rnb=$connexion->query("select count(*) from information_schema.tables where table_schema = 'public'");
		while ($lg = $rnb->fetch(PDO::FETCH_ASSOC)) {   
			$nbTables = $lg['count'];
		}

		$requete="select table_name from information_schema.tables where table_schema = 'public'";
		$resultat=$connexion->query($requete);
		$i=1;
		while ($ligne = $resultat->fetch(PDO::FETCH_ASSOC)) {   
			$prim = '';
			$className = $ligne['table_name'];
			//first letter in upper 
			$className=strtoupper(substr($className, 0, 1)).substr($className, 1, strlen($className)-1);
			echo '-----------------------------------
			'.$i.'/'.$nbTables.' - Table '.$className.'
			';
			$entityFilename = $entityPath.'/'.$className.'.php';
			$modelFilename = $modelPath.'/Mod'.$className.'.php';
		   	$entfile = fopen( $entityFilename, "w+" );
		   	$modfile = fopen( $modelFilename, "w+" );
		   	if( $entfile == false) {
		      echo ( "Error in opening entity file" );
		      exit();
		   	}
		   	if( $entfile == false) {
		      echo ( "Error in opening model file" );
		      exit();
		   	}
			$requete="Select * from information_schema.columns where table_name='".$ligne['table_name']."'";
			$res2=$connexion->query($requete);

			//creating files
			fwrite( $entfile, "<?php \n");
			fwrite( $modfile, "<?php \n");

			//hearder
			fwrite( $entfile, "namespace App\Entities;\n");
			fwrite( $entfile, "use CodeIgniter\Entity\Entity;\n");
			fwrite( $entfile, "use App\Models\Mod".$className.";\n");
			fwrite( $modfile, "namespace App\Models;\n");
			fwrite( $modfile, "use CodeIgniter\Model;\n");
			fwrite( $modfile, "use App\Entities\\".$className.";\n\n");
			$lProp = $res2->fetchAll(PDO::FETCH_ASSOC);
			//var_dump($lProp);continue;
			//getting primary key
			$sqlPK = "select table_name from`INFORMATION_SCHEMA`.`COLUMNS` where COLUMN_NAME = '".$prim."' and TABLE_SCHEMA = '".$dbname."' and table_name != '".$ligne['table_name']."'";
			$sqlPK = "SELECT c.column_name, c.data_type
					FROM information_schema.table_constraints tc 
					JOIN information_schema.constraint_column_usage AS ccu USING (constraint_schema, constraint_name) 
					JOIN information_schema.columns AS c ON c.table_schema = tc.constraint_schema
					  AND tc.table_name = c.table_name AND ccu.column_name = c.column_name
					WHERE constraint_type = 'PRIMARY KEY' and tc.table_name = '".$ligne['table_name']."';";
			
			$resPk=$connexion->query($sqlPK)->fetchAll(PDO::FETCH_ASSOC);
			
			$prim = $resPk[0]['column_name'];
			
			//getting foreign keys
			$sqlFK = "SELECT ccu.table_name, ccu.column_name
				FROM information_schema.table_constraints tc
				join information_schema.constraint_column_usage ccu on tc.constraint_name = ccu.constraint_name
				where tc.constraint_type = 'FOREIGN KEY'
				and tc.table_name='".$ligne['table_name']."';";
			
			$resFk=$connexion->query($sqlFK);
			$lstFk = $resFk->fetchAll(PDO::FETCH_ASSOC);
			//var_dump($lstFk);continue;
			foreach ($lstFk as $lfk) {   
				$fkName=strtoupper(substr($lfk['table_name'], 0, 1)).substr($lfk['table_name'], 1, strlen($lfk['table_name'])-1);
				fwrite( $entfile, "use App\Models\Mod".$fkName.";\n");
			}


			fwrite( $entfile, "\n");
			// class name
			fwrite( $entfile, "class ".$className." extends Entity {\n\n");
			fwrite( $modfile, "class Mod".$className." extends Model {\n\n");

			//Model protected properties
			fwrite( $modfile, "\t".'protected $'."DBGroup  = 'default';\n");
			fwrite( $modfile, "\t".'protected $'."table= '".$ligne['table_name']."';\n");
			
			fwrite( $modfile, "\t".'protected $'."returnType   = 'App\Entities\\".$className."';\n");
			fwrite( $modfile, "\t".'protected $'."useSoftDeletes   = true;\n");
			fwrite( $modfile, "\t".'protected $'."protectFields= true;\n");
			fwrite( $modfile, "\t".'protected $'."db;\n\n");
			fwrite( $modfile, "\t".'protected $'."useTimestamps= true;\n");
			fwrite( $modfile, "\t".'protected $'."dateFormat   = 'datetime';\n");
			fwrite( $modfile, "\t".'protected $'."createdField = 'createdat';\n");
			fwrite( $modfile, "\t".'protected $'."updatedField = 'updatedat';\n");
			fwrite( $modfile, "\t".'protected $'."deletedField = 'deletedat';\n\n");

			fwrite( $modfile, "\t".'protected $'."allowedFields = [\n");
			//properties
		   	
			foreach ($lProp as $prop) {
				fwrite( $modfile, "\t\t".'"'.$prop['column_name'].'"'.",\n");
			}
			fwrite( $modfile, "\t];\n");
			fwrite( $modfile, "\t".'protected $'."primaryKey   = '".$prim."';\n\n");

			
			//getters and setters
			fwrite( $entfile, "\t//getters and setters\n");
			foreach ($lProp as $prop) {
				//getters
				$propName=strtoupper(substr($prop['column_name'], 0, 1)).substr($prop['column_name'], 1, strlen($prop['column_name'])-1);
				fwrite( $entfile, "\tpublic function get".$propName."(){\n");
					fwrite( $entfile, "\t\t".'return $this->attributes['."'".$prop['column_name']."']".';'."\n");
				fwrite( $entfile, "\t}\n\n");

				//setters
				fwrite( $entfile, "\tpublic function set".$propName."($".$prop['column_name']."){\n");
					// fwrite( $file, );
					fwrite( $entfile, "\t\t".'$this->attributes['."'".$prop['column_name']."']".'=$'.$prop['column_name'].';'."\n");
				fwrite( $entfile, "\t}\n\n");
				 // var_dump($line2);
			}

			
			foreach ($lProp as $prop) {
				//check if it is a fk
				$sqlProFk = "SELECT tc.table_name
					FROM information_schema.table_constraints tc
					join information_schema.constraint_column_usage ccu on tc.constraint_name = ccu.constraint_name
					where tc.constraint_type = 'FOREIGN KEY' and tc.table_name != '".$ligne['table_name']."'
					and ccu.column_name='".$prop['column_name']."'";
				$resProFk=$connexion->query($sqlProFk)->fetchAll(PDO::FETCH_ASSOC);
				//var_dump($resProFk);continue;

				if (!empty($resProFk)) {

					//getting N-1 or N-N links
					fwrite( $entfile, "\t//getting N-1 or N-N links\n");
					foreach ($resProFk as $pfk) {
						$fkCls=strtoupper(substr($pfk['table_name'], 0, 1)).substr($pfk['table_name'], 1, strlen($pfk['table_name'])-1);
						if (!in_array(strtolower($fkCls), $exclude_tab)){
							fwrite( $entfile, "\tpublic function get".$fkCls."s(){\n");
							
							fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkCls."();\n");
							fwrite( $entfile, "\t\t".'return $obj->where1(\''.$prim.' = \'. $this->'.$prim.');'."\n");
							fwrite( $entfile, "\t}\n\n");
						}
					}

					//clearing children tables
					fwrite( $entfile, "\t//clearing\n");
					foreach ($resProFk as $lfk) {   
						$fkName=strtoupper(substr($lfk['table_name'], 0, 1)).substr($lfk['table_name'], 1, strlen($lfk['table_name'])-1);
						fwrite( $entfile, "\tpublic function clear".$fkName."s(){\n");
						fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkName.'();'."\n");
						fwrite( $entfile, "\t\t".'return $obj->where(\''.$prim.' = \'. $this->'.$prim.')->delete();'."\n");
						fwrite( $entfile, "\t}\n\n");
					}

					//getSome children tables
					fwrite( $entfile, "\t//getSome\n");
					foreach ($resProFk as $lfk) {
						$fkName=strtoupper(substr($lfk['table_name'], 0, 1)).substr($lfk['table_name'], 1, strlen($lfk['table_name'])-1);
						fwrite( $entfile, "\tpublic function getSome".$fkName."s(".'$nb'."){\n");
						fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkName.'();'."\n");
						fwrite( $entfile, "\t\t".'return $obj->whereSome(\''.$prim.' = \'. $this->'.$prim.', $nb);'."\n");
						fwrite( $entfile, "\t}\n\n");
					}

					//getFirst children tables
					fwrite( $entfile, "\t//getFirst\n");
					foreach ($resProFk as $lfk) {
						$fkName=strtoupper(substr($lfk['table_name'], 0, 1)).substr($lfk['table_name'], 1, strlen($lfk['table_name'])-1);
						fwrite( $entfile, "\tpublic function getFirst".$fkName."(){\n");
						fwrite( $entfile, "\t\t".'$lst = $this->get'.$fkName.'s();'."\n");
						fwrite( $entfile, "\t\t".'$n = count($lst);'."\n");
						fwrite( $entfile, "\t\t".'$rep = ($n==0) ? null : $lst[0] ;'."\n");
						fwrite( $entfile, "\t}\n\n");
					}

					//getLast children tables
					fwrite( $entfile, "\t//getLast\n");
					foreach ($resProFk as $lfk) {  
						$fkName=strtoupper(substr($lfk['table_name'], 0, 1)).substr($lfk['table_name'], 1, strlen($lfk['table_name'])-1);
						fwrite( $entfile, "\tpublic function getLast".$fkName."(){\n");
						fwrite( $entfile, "\t\t".'$lst = $this->get'.$fkName.'s();'."\n");
						fwrite( $entfile, "\t\t".'$n = count($lst);'."\n");
						fwrite( $entfile, "\t\t".'$rep = ($n==0) ? null : $lst[$n-1] ;'."\n");
						fwrite( $entfile, "\t}\n\n");
					}
				}
			}

			//incoming FK
			fwrite( $entfile, "\t//incoming FK\n");
			foreach ($lstFk as $lfk) {   
				$fkName=strtoupper(substr($lfk['table_name'], 0, 1)).substr($lfk['table_name'], 1, strlen($lfk['table_name'])-1);
				fwrite( $entfile, "\tpublic function get".$fkName."(){\n");

				fwrite( $entfile, "\t\t".'if (empty($this->'.$lfk['table_name'].')) return null;'."\n");
				fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkName."();\n");
				fwrite( $entfile, "\t\t".'return $obj->findPk($this->'.$lfk['table_name'].');'."\n");
				fwrite( $entfile, "\t}\n\n");
			}


			//getData
			fwrite( $entfile, "\t//getData\n");
			fwrite( $entfile, "\tpublic function getData(){\n");
				fwrite( $entfile, "\t\t".'return $this->attributes;'."\n");
			fwrite( $entfile, "\t}\n\n");

			//findPk
			fwrite( $modfile, "\tpublic function findPk(".'$id'."){\n");
				fwrite( $modfile, "\t\t".'$ret = $this->find($id);'."\n");
				fwrite( $modfile, "\t\t".'if(empty($ret)) return null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($ret)) return $ret[0];'."\n");
				fwrite( $modfile, "\t\t".'return $ret;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//getFirst
			fwrite( $modfile, "\tpublic function getFirst(){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($this->primaryKey,"asc")->findAll(1,0);'."\n");
	        fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//getLast
			fwrite( $modfile, "\tpublic function getLast(){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($this->primaryKey,"desc")->findAll(1,0);'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");
			
			//findSome
			fwrite( $modfile, "\tpublic function findSome(".'$nb'."){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($this->primaryKey,"desc")->findAll($nb,0);'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//findAllOrder
			fwrite( $modfile, "\tpublic function findAllOrder(".'$col, $type'."){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($col,$type)->findAll();'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");


			//findOrder
			fwrite( $modfile, "\tpublic function findOrder(".'$col, $type, $nb'."){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($col,$type)->findAll($nb,0);'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//where
			fwrite( $modfile, "\tpublic function where1(".'$params'."){\n");
				fwrite( $modfile, "\t\t".'$lst = null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$keys = array_keys($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$vals = array_values($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($keys[0], $vals[0]);'."\n");
		        fwrite( $modfile, "\t\t\t".'for ($i=1; $i < count($keys); $i++) { '."\n");
		        fwrite( $modfile, "\t\t\t\t".'$lst = $lst->where($keys[$i], $vals[$i]);'."\n");
		        fwrite( $modfile, "\t\t\t".'}'."\n");
		        fwrite( $modfile, "\t\t".'} elseif (is_numeric($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($this->primaryKey,$params);'."\n");
		        fwrite( $modfile, "\t\t".'} else{'."\n");
		        fwrite( $modfile, "\t\t\t".'$t = explode("=",$params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where(trim($t[0]),trim($t[1]));'."\n");
		        fwrite( $modfile, "\t\t".'}'."\n");
				fwrite( $modfile, "\t\t".'return $lst->findAll();'."\n");
			fwrite( $modfile, "\t}\n\n");

			//whereOrder
			fwrite( $modfile, "\tpublic function whereOrder(".'$params, $col, $type, $nb'."){\n");
				fwrite( $modfile, "\t\t".'$lst = null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$keys = array_keys($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$vals = array_values($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($keys[0], $vals[0]);'."\n");
		        fwrite( $modfile, "\t\t\t".'for ($i=1; $i < count($keys); $i++) { '."\n");
		        fwrite( $modfile, "\t\t\t\t".'$lst = $lst->where($keys[$i], $vals[$i]);'."\n");
		        fwrite( $modfile, "\t\t\t".'}'."\n");
		        fwrite( $modfile, "\t\t".'} elseif (is_numeric($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($this->primaryKey,$params);'."\n");
		        fwrite( $modfile, "\t\t".'} else{'."\n");
		        fwrite( $modfile, "\t\t\t".'$t = explode("=",$params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where(trim($t[0]),trim($t[1]));'."\n");
		        fwrite( $modfile, "\t\t".'}'."\n");
		        fwrite( $modfile, "\t\t".'if ($nb==(-1)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'return $lst->orderBy($col, $type)->findAll();'."\n");
		        fwrite( $modfile, "\t\t".'}'."\n");
				fwrite( $modfile, "\t\t".'return $lst->orderBy($col, $type)->findAll($nb,0);'."\n");
			fwrite( $modfile, "\t}\n\n");

			//whereSome
			fwrite( $modfile, "\tpublic function whereSome(".'$params, $nb'."){\n");
				fwrite( $modfile, "\t\t".'$lst = null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$keys = array_keys($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$vals = array_values($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($keys[0], $vals[0]);'."\n");
		        fwrite( $modfile, "\t\t\t".'for ($i=1; $i < count($keys); $i++) { '."\n");
		        fwrite( $modfile, "\t\t\t\t".'$lst = $lst->where($keys[$i], $vals[$i]);'."\n");
		        fwrite( $modfile, "\t\t\t".'}'."\n");
		        fwrite( $modfile, "\t\t".'} elseif (is_numeric($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($this->primaryKey,$params);'."\n");
		        fwrite( $modfile, "\t\t".'} else{'."\n");
		        fwrite( $modfile, "\t\t\t".'$t = explode("=",$params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where(trim($t[0]),trim($t[1]));'."\n");
		        fwrite( $modfile, "\t\t".'}'."\n");
				fwrite( $modfile, "\t\t".'return $lst->findAll($nb,0);'."\n");
			fwrite( $modfile, "\t}\n\n");

			//save
			fwrite( $entfile, "\tpublic function save(){\n");
			fwrite( $entfile, "\t\t".'$model = new Mod'.$className.'();'."\n");
	        fwrite( $entfile, "\t\t".'$data = $this->getData();'."\n");
	        fwrite( $entfile, "\t\t".'return $model->saveData($data);'."\n");
			fwrite( $entfile, "\t}\n\n");

			//saveData
			fwrite( $modfile, "\t".'public function saveData($data){'."\n");
		    fwrite( $modfile, "\t\t".'if (!array_key_exists($this->primaryKey, $data)) {'."\n");
		    fwrite( $modfile, "\t\t\t".'$ret = $this->insert($data);'."\n");
		    fwrite( $modfile, "\t\t\t".'return $ret;'."\n");
		    fwrite( $modfile, "\t\t".'}else{'."\n");
		    fwrite( $modfile, "\t\t\t".'$data[$this->updatedField]=date("Y-m-d H:i:s");'."\n");
		    fwrite( $modfile, "\t\t\t".'$ret = $this->where([$this->primaryKey => $data[$this->primaryKey]])->set($data)->update();'."\n");
		    fwrite( $modfile, "\t\t\t".'return $ret;'."\n");
		    fwrite( $modfile, "\t\t}\n");
			fwrite( $modfile, "\t}\n\n");
			
			$i++;
			//end of class
			fwrite( $entfile, "}");
		   	fclose( $entfile );
			fwrite( $modfile, "}");
		   	fclose( $modfile);
		}

			echo "----------------------------------- \nModel generated successfuly";
	}else{
		echo 'Error Connection to DB';
	}

?>