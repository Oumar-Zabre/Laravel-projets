<?php
namespace App\Libraries;

class Tools {


// Fonction pour unifier le tableau d'objets
function uniObjets($tableauObjets) {
    $tableauUnique = [];
    foreach ($tableauObjets as $objet) {
        $tableauUnique[$objet->iduser] = $objet;
    }
    return array_values($tableauUnique);
}
    
    /* PROPRIÉTÉES STATIQUES */
    public function getFrom(){
      return 'contact@comptechnoafrique.com';  
    }  

    /* FONCTIONS STATIQUES */
    public function in($val, $min, $max){
        return ($val>=$min && $val<=$max) ? true : false ;
    }

    public function getRandomWord($lg){
        $generator = "ABCDEFGHJKLMNPQRSTUVWXYZ123456789";
        $result = "";
        for ($i = 1; $i <= $lg; $i++) {
            $result .= substr($generator, rand() % strlen($generator), 1);
        }
        // Returning the result
        return $result;
    }

     public function getRandomcodecolis($lg){
        $generator = "ABCDEFGHJKL123TUVWXYZ456789MNPQRS";
        $result = "";
        for ($i = 1; $i <= $lg; $i++) {
            $result .= substr($generator, rand() % strlen($generator), 1);
        }
        // Returning the result
        return $result;
    }

    public function getRandomPassword() {
        $length = mt_rand(6, 10);
        // Certains caractères ont été enlevés car ils prêtent à confusion
        $chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjklmnpqrstuvwxyz123456789&é(-è_çà)=~#{[|^@]}";
        $password = substr(str_shuffle($chars), 0, $length);
        return $password;
    }

    public function getAcronyme($sentence) {
        $words = explode(" ", $sentence);
        $acronym = "";
        foreach ($words as $w) {
            $acronym .= $w[0];
        }
        return $acronym;
    }

    public function create_slug($string) {
        $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
        return $slug;
    }

    public function hashPwd($pwd) {
        return sha1(sha1(md5($pwd)));
    }

    public function last($arr) {
        $nb = count($arr);
        if ($nb>0) {
            return $arr[$nb-1];
        }
        return NULL;
    }
    
    public function get($arr, $n) {
        $nb = count($arr);
        if ($nb>=($n+1)) {
            return $arr[$n];
        }
        return NULL;
    }
    public function boolToString($value){
        if ($value==1) {
            return 'Oui';
        }
        return 'Non';
    }
    public function toMySqlDateformat($date,$with_hours){
        if (empty($date)) {
            return '';
        }
        if ($with_hours) {
            return date('Y-m-d H:i:s',strtotime(str_replace('/', '-', $date)));
        }
        return date('Y-m-d',strtotime(str_replace('/', '-', $date)));
    }

    public function fromMySqlDateformat($date,$with_hours){
        if (empty($date)) {
            return '';
        }
        if ($with_hours) {
            return date('d/m/Y H:i:s',strtotime(str_replace('-', '/', $date)));
        }
        return date('d/m/Y',strtotime(str_replace('-', '/', $date)));
    }

    public function stringToBool($value){
        if ($value=='Oui') {
            return 1;
        }
        return 0;
    }

    public function getPeriode($date){
        $tab=explode('-',$date);
        $annee = (int)$tab[0];
        $mois = (int)$tab[1];
        if($mois==12){
            $mois=1;
            $annee++;
        }else{
            $mois++;
        }
        return $annee.'-'.$mois;
    }

    public function getPeriodeBack($date){
        $tab=explode('-',$date);
        $annee = (int)$tab[0];
        $mois = (int)$tab[1];
        if($mois==1){
            $mois=12;
            $annee--;
        }else{
            $mois--;
        }
        return $annee.'-'.$mois;
    }   

    public function periodeToFrench($date){
        $tab=explode('-',$date);
        $annee = (int)$tab[0];
        $mois = (int)$tab[1];
        return $mois.'/'.$annee;
    }

    public function dateToJs($datetime, $with_hours){
        if ($with_hours) {
            
        }else{
            $tab=explode('-',$datetime);
            $annee = (int)$tab[0];
            $mois = (int)$tab[1];
            $jour = (int)$tab[2];
            return $annee.', '.$mois.', '.$jour;
        }
    }

    public function image_resize($path,$size){
        $config_resize = array();
        $config_resize['image_library'] = 'gd2';
        $config_resize['source_image'] = $path;
        $config_resize['minimum_ratio'] = TRUE;
        $config_resize['width'] = 75;
        $config_resize['height'] = 50;
        $config_resize['new_image'] = './assets/images/thumb/'.$file;
        $this->load->library('image_lib',$config_resize);
        $this->image_lib->resize();
    }

    /**************************************************************************************
    * Fonction permettant de charger et d'enregistrer les fichiers sur le serveur
    * Arguments : 
    *   $tab : l'objet $_FILES contenant les info sur le fichier
    *   $url : adresse du dossier devant contenir le fichier
    *   $allowed : liste des extensions autorisées sous forme de tableau
    *   $name : nouveau nom du fichier
    *   $field : nom du champs HTML ayant servi à choisir le fichier   
    ****************************************************************************************/
    public function do_upload_file($tab, $url, $allowed, $name, $field){
        $image=basename($tab[$field]['name']);
        $image=str_replace(' ','|',$image);
        $type = explode(".",$image);
        $type = $type[count($type)-1];
        if (in_array($type,$allowed)){
            $tmppath=$url.'/'.$name.".".$type; // GENRATION DU NOUVEAU NOM DU FICHIER
            $ret = $name.".".$type;
            if(is_uploaded_file($tab[$field]["tmp_name"])){
                if(file_exists($this->getSiteRootFolder().$tmppath)){
                    unlink($tmppath);
                }
                move_uploaded_file($tab[$field]['tmp_name'],$tmppath);
                return $ret; // returns the url of uploaded image.
            }
            return 'cc1';
        }
        return 'cc2';
    }

    public function do_upload_file_nofilter($tab, $url, $name, $field){
        $image=basename($tab[$field]['name']);
        $image=str_replace(' ','|',$image);
        $tmppath=$name.".".$type; // GENRATION DU NOUVEAU NOM DU FICHIER
        if(is_uploaded_file($tab[$field]["tmp_name"])){
            if(file_exists(Tools::getSiteRootFolder().$tmppath)){
                unlink($tmppath);
            }
            move_uploaded_file($tab[$field]['tmp_name'],$tmppath);
            return $tmppath; // returns the url of uploaded image.
        }
        return 'cc1';
    }

    public function getSiteRootFolder(){
        return $_SERVER['DOCUMENT_ROOT'].'';
    }

    public function is_home(){
        /*
        $CI =& get_instance();
        $is_home = ($CI->router->fetch_class() === 'frontend' && $CI->router->fetch_method() === 'index') ? true : false;
        */
        $router = service('router');
        $controller  = $router->controllerName();
        $method = $router->methodName();
        $is_home = ($controller === '\App\Controllers\Frontend' && $method === 'index') ? true : false;

        return $is_home;
    }

    public function getURI(){
        /*
        $CI =& get_instance();
        return $CI->router->fetch_class().'/'.$CI->router->fetch_method();
        */
        $router = service('router');
        $controller  = $router->controllerName();
        $method = $router->methodName();
        return $controller.'/'.$method;
    }

    public function sort($tab, $order){
        if(count($tab)<2) return $tab;
        $out=false;
        while(!$out){
            $out=true;
            for ($i=1; $i < count($tab); $i++) { 
                if ($order=='a') {
                    if($tab[$i-1][1]>$tab[$i][1]){
                        $tmp = $tab[$i-1];
                        $tab[$i-1] = $tab[$i];
                        $tab[$i] = $tmp;
                        $out=false;
                    }
                } else {
                    if($tab[$i-1][1]<$tab[$i][1]){
                        $tmp = $tab[$i-1];
                        $tab[$i-1] = $tab[$i];
                        $tab[$i] = $tmp;
                        $out=false;
                    }
                }
            }
        }
        return $tab;
    }

    public function quote($str){
        return '\''.$str.'\'';
    }

    public function getAge($dnais){
        list($y, $m, $d) = explode('-', $dnais);
        $age = date('Y')-$y;
        return $age;
    }

    public function getTimeAgo( $time ){
        $time_difference = time() - $time;
        if( $time_difference < 1 ) { return "il y a moins d'1e seconde"; }
        $condition = array( 12 * 30 * 24 * 60 * 60 =>  'an',
                    30 * 24 * 60 * 60       =>  'mois',
                    24 * 60 * 60            =>  'jour',
                    60 * 60                 =>  'heure',
                    60                      =>  'minute',
                    1                       =>  'seconde'
        );
        foreach( $condition as $secs => $str ){
            $d = $time_difference / $secs;
            if( $d >= 1 ){
                $t = round( $d );
                return 'il y a ' . $t . ' ' . $str . ( $t > 1 ? 's' : '' );
            }
        }
    }

    /* FONCTION NON STATIQUES */
    public function __sendMail($displayName = "",$message, $to, $subject, $file= null){
        $CI = &get_instance();
        $CI->load->library('email');
        $from = Tools::getFrom();
        $config = array(
            'protocol' => 'sendmail',
            'mailtype' => 'html', 
            'charset' => 'utf-8',
            'wordwrap' => TRUE
        );
        $CI->email->set_header('Content-Type', 'text/html');
        $CI->email->initialize($config);
        $CI->email->from($from, $displayName);
        //$this->email->to('contact@jeunecreationfrancophone.org');
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($message);
        //$this->email->attach(base_url('assets/_pdffiles/commission/inscrit_'.$id.'.pdf'));
        $CI->email->send();
    }

    public function sendMail($displayName = "",$message, $to, $subject, $file= null) { 
        $email = \Config\Services::email();
        $email->setTo($to);
        $email->setFrom($this->getFrom(), $displayName);
        $email->setMailType('html');
        $email->setSubject($subject);
        $email->setMessage(htmlspecialchars_decode($message));
        if ($email->send()) {
            echo '1';
        }else {
            $data = $email->printDebugger(['headers']);
            print_r($data);
        }
    }

    public function numberformat($number, $with_decimal){
        if ($with_decimal==true) {
            return number_format($number, 2, ',', ' ');
        }
        return number_format($number, 0, ',', ' ');
    }

    public function sendConfEmail($nompren,$email, $otp){
       // $CI =& get_instance();
        //ob_start();
        $msg='
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Confirmation de votre adresse email</title>
            <style>
                .btn{
                    font-size: 14px;
                    padding: 10px 30px;
                    border-radius: 4px;
                    letter-spacing: 1px;
                    font-weight: 400;
                    color: #fff;
                    border: none;
                    text-transform: uppercase;
                    transition: all 0.3s ease-in-out;
                    display: inline-block;
                    text-align: center;
                    white-space: nowrap;
                    vertical-align: middle;
                    line-height: 1.5;
                    text-decoration: none;
                }
            </style>
        </head>
        <body>
            <h3>Bonjour '.$nompren.',</h3>
            <p>Merci d\'avoir créer votre compte candidat sur la plateforme de recrutement du Cabinet Hope Consult.</p>
            <hr/>
            <p>Veuillez cliquer <a  href="https://comptechnoafrique.com/demos/recrutement.hopeconsult/public/Login/confirmemail/?otp='.$otp.'"> sur ce lien </a> pour activer votre compte et commencer à completer votre compte et postuler aux différentes offres.</p><br>
            <p>Encore merci et bienvenue</p>
            <strong>L\'équipe de <strong>Cabinet Hope Consult</strong>
        </body>
        </html>';
        //echo $msg;
        Tools::sendMail('[Hope Consult] Bienvenu', $msg,$email,'Confirmation email');
    }
    public function sendConfNumb($cand){
        $CI = get_instance() ;
        //ob_start();
        $civ = ($cand->getGenre()=='f') ? 'Mme' : 'M.' ;
        $nomcand = strtoupper($cand->getNom()).' '.$cand->getPrenom();
        $msg='
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Confirmation de votre adresse email</title>
            <style>
                .btn{
                    font-size: 14px;
                    padding: 10px 30px;
                    border-radius: 4px;
                    letter-spacing: 1px;
                    font-weight: 400;
                    color: #fff;
                    border: none;
                    text-transform: uppercase;
                    transition: all 0.3s ease-in-out;
                    display: inline-block;
                    text-align: center;
                    white-space: nowrap;
                    vertical-align: middle;
                    line-height: 1.5;
                    text-decoration: none;
                }
                .btn-common{
                    background: #00BCD4;
                    position: relative;
                    z-index: 1;
                }
            </style>
        </head>
        <body>
            Bonjour '.$civ.' '.$nomcand.'.<br>Nous avons lancé un projet d\'amélioration de notre base de données de CV à laquelle vous êtes inscrit. Cette amélioration entraîne un changement dans le format des numéro de téléphones enregistrés sur la plateforme. Nous vous demandons donc de vous connecter pour <strong>corriger ou confirmer votre numéro de téléphone</strong>. Si vous ne faites pas cela, vous risquer de <strong>ne pas recevoir les notifications SMS provenant de notre plateforme</strong>.Merci<br>
            L\'équipe de <strong>Cabinet Hope Consult</strong>
        </body>
        </html>';
        //echo $msg;
        Tools::sendMail('Cabinet Hope Consult - Base de données de CVs et offres d\'emploi', $msg,$cand->getEmail(),'Confirmation de votre numéro de téléphone');
    }
    public function _sendNotif($email, $offre){
        $CI =& get_instance();
        // ob_start();
        $msg='
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Résultat de l\'offre de récrutement '.$offre.' </title>
            <style>
                .btn{
                    font-size: 14px;
                    padding: 10px 30px;
                    border-radius: 4px;
                    letter-spacing: 1px;
                    font-weight: 400;
                    color: #fff;
                    border: none;
                    text-transform: uppercase;
                    transition: all 0.3s ease-in-out;
                    display: inline-block;
                    text-align: center;
                    white-space: nowrap;
                    vertical-align: middle;
                    line-height: 1.5;
                    text-decoration: none;
                }
                .btn-common{
                    background: #00BCD4;
                    position: relative;
                    z-index: 1;
                }
            </style>
        </head>
        <body>
            <p>Bonjour chèr(e) candidat . Nous avons le regrèt de vous informer que votre candidature à l\'offre '.$offre.'. Nous nous excusons des désagréments et vous encorrageons à postuler à d\'autres offres. Encore merci pour votre confiance. <br />
            L\'équipe de <strong>Cabinet Hope Consult</strong>
        </body>
        </html>';
        //echo $msg;
        // $msg = 'test';
        Tools::sendMail("Cabinet Hope Consult - Résultat de l'offre de récrutement ".$offre, $msg,$email,'Confirmation email');
    }
    public function sendNotif($interet, $ctmsg){
        //remplacement des mots clés par leurs valeurs
        $CI =& get_instance();
        $cand = $interet->getCandidat();
        $offre = $interet->getOffre();
        $civ = ($cand->getGenre()=='h') ? 'M.' : 'Mme' ;
        $lnom = $civ.' '.strtoupper($cand->getNom()).' '.$cand->getPrenom();
        $loffre = 'Recrutement de '.$offre->getNbrpersonnes().' '.$offre->getProfil()->getLibprofil();
        $ctmsg = str_replace('%NOM%', $lnom, $ctmsg);
        $ctmsg = str_replace('%OFFRE%', $loffre, $ctmsg);
        $ctmsg = str_replace('%RL%', '<br>', $ctmsg);
        $ctmsg = str_replace('%SITE%', '<a href="http://www.recrutement.cabinet-hope-consult.com">www.recrutement.cabinet-hope-consult.com</a>', $ctmsg);
        $email = $cand->getEmail();
        $msg='
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Résultat de l\'offre de récrutement '.$loffre.' </title>
            <style>
                .btn{
                    font-size: 14px;
                    padding: 10px 30px;
                    border-radius: 4px;
                    letter-spacing: 1px;
                    font-weight: 400;
                    color: #fff;
                    border: none;
                    text-transform: uppercase;
                    transition: all 0.3s ease-in-out;
                    display: inline-block;
                    text-align: center;
                    white-space: nowrap;
                    vertical-align: middle;
                    line-height: 1.5;
                    text-decoration: none;
                }
                .btn-common{
                    background: #00BCD4;
                    position: relative;
                    z-index: 1;
                }
            </style>
        </head>
        <body>'.$ctmsg.'</body>
        </html>';
        // echo $msg;die();
        // $msg = 'test';
        Tools::sendMail("Cabinet Hope Consult - Résultat de l'offre de récrutement ".$loffre, $msg,$email,'Résultat de offre de récrutement');
        Tools::sendSMS($cand->getTel(), $ctmsg);
        return;
    }
    public function sendSMS($numb, $msg){
        $ret = SmsTools::sendSmsbusPOST($numb,$msg);
        return $ret['code'];
    }
    public function dateDiff($d1, $d2){
        return round(abs(strtotime($d1)-strtotime($d2))/86400);
    }
    public function getYear($date){
        // return date('Y',strtotime($date));
        return substr($date, 0, 4);
    }
    public function getMonth($date){
        $y = substr($date, 0, 4);
        $m = substr($date, 5, 2); 
        return $m.'/'.$y;
    }
    public function getBirthday($age){
        list($y, $m, $d) = explode('-', date('Y-m-d'));
        $range = $y - $age;
        return date('Y-m-d',strtotime("{$range}-$m-$d"));
    }
    public function sendResetEmail($email, $npwd){
        //$CI =& get_instance();
        $msg = '
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Confirmation de votre adresse email</title>
            <style>
                .btn{
                    font-size: 14px;
                    padding: 10px 30px;
                    border-radius: 4px;
                    letter-spacing: 1px;
                    font-weight: 400;
                    color: #fff;
                    border: none;
                    text-transform: uppercase;
                    transition: all 0.3s ease-in-out;
                    display: inline-block;
                    text-align: center;
                    white-space: nowrap;
                    vertical-align: middle;
                    line-height: 1.5;
                    text-decoration: none;
                }
                .btn-common{
                    background: #00BCD4;
                    /*position: relative;
                    z-index: 1;*/
                }
            </style>
        </head>
        <body>
            <p>Bonjour cher(e) visiteur/visiteuse.</p>
            <p>
                Voici votre nouveau mot de passe <strong>'.$npwd.'</strong>. Merci
            </p>
            <p>
        Veuillez cliquer sur ce <a class="btn btn-common" href="'.site_url('/login').'">bouton</a> pour vous connecter.<br>
            </p>
            <p>L\'equipe de <strong>Logistec</strong></p>
        </body>
    </html>    
        ';
        //echo $msg;
        Tools::sendMail('ComparEtConseil', $msg,$email,'Reinitialisation de mot de passe');
    }
    public function sendContactEmail($nom, $email, $subject, $message){
       // $CI =& get_instance();
        $msg = '
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Nouveau message</title>
            <style>
                
            </style>
        </head>
        <body>
            <h1>Nouveau message du formulaire de contact</h1>
            <table>
                <tbody>
                    <tr>
                        <td>Nom</td>
                        <td><strong>'.$nom.'</strong></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><strong><a href="mailto:'.$email.'">'.$email.'</a></strong></td>
                    </tr>
                    <tr>
                        <td>Objet du message</td>
                        <td><strong>'.$subject.'</strong></td>
                    </tr>
                    <tr>
                        <td>Contenu du message</td>
                        <td><strong>'.$message.'</strong></td>
                    </tr>
                </tbody>
            </table>
        </body>
    </html>    
        ';
        // $msg=ob_get_clean();
        $to = Tools::getFrom();
        //echo $msg; die();
        Tools::sendMail('ComparEtConseil', $msg, $to,'Nouveau message du formulaire de contact');
    }
}
?>