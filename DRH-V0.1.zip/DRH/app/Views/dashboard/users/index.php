<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.0/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Arimo:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/public/admin/assets/styles.css">
<div class="container">
   <div class="page-inner">
      <div class="page-header">
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header d-flex align-items-center justify-content-between bg-dark_ text-white" style="background-color:#343232;">
                  <strong class="mb-0 h2">La liste des utilisateurs</strong>
                  <div class="d-flex align-items-center">
                     <button class="btn btn-primary me-2" onclick="exportTableToExcel('basic-datatables', 'La liste de tous les utilisateurs')">
                     Exporter en Excel
                     </button>
                     <a href="#" class="btn btn-round_">
                     <i class="fa fa-plus"></i> Ajouter
                     </a>
                  </div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="basic-datatables" class="display table table-hover table-bordered table-striped">
                        <thead class="bg-primary text-white">
                           <tr>
                              <th>
                                 <div class="fs-6 fw-bold">ID</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Nom</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Poste</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Role</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Actions</div>
                              </th>
                           </tr>
                        </thead>
                        <tfoot class="bg-light">
                           <tr>
                              <th>
                                 <div class="fs-6 fw-bold">ID</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Nom</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Poste</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Role</div>
                              </th>
                              <th>
                                 <div class="fs-6 fw-bold">Actions</div>
                              </th>
                           </tr>
                        </tfoot>
                        <tbody>
                           <tr>
                              <td>
                                 <div class="d-flex">
                                    <a class="fw-bold text-info" href="#">
                                    DRH234BV
                                    </a>
                                    <button class="btn btn-sm ms-2" onclick="copyToClipboard('<?php echo 'DRH234BV' ?>', this)">
                                    <i class="fas fa-copy"></i>
                                    <span class="copy-feedback d-none ms-2">
                                    <i class="fas fa-check-circle text-success"></i>
                                    <span class="ms-2">Copié</span>
                                    </span>
                                    </button>
                                 </div>
                              </td>
                              <td class="text-dark fw-semibold" title="" style="font-size: 14px;">
                                 KONFE W.Madi
                              </td>
                              <td>
                                 <span class="badge badge-success p-2">Directeur Financier</span>
                              </td>
                              <td>
                                 <form method="post" action="#" class="d-flex justify-content-center">
                                    <input type="hidden" value="#" name="tiduser">
                                    <select name="idroleuser" class="form-select form-select-sm me-2" id="idroleuser">
                                       <option value="1">
                                          S.Admin
                                       </option>
                                       <option value="1">
                                          Admin
                                       </option>
                                       <option value="1">
                                          User
                                       </option>
                                    </select>
                                    <button class="btn btn-sm btn-primary" name="btn-role">Valider</button>
                                 </form>
                              </td>
                              <td>
                                 <a href="#" class="btn btn-link text-danger">
                                 <i class="fa fa-times fw-bold"></i>
                                 </a>
                                 <a href="#" class="btn btn-link text-dark">
                                 <i class="fa fa-edit fw-bold"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr>
                              <td>
                                 <div class="d-flex">
                                    <a class="fw-bold text-info" href="#">
                                    DRH857KJ
                                    </a>
                                    <button class="btn btn-sm ms-2" onclick="copyToClipboard('<?php echo 'DRH857KJ' ?>', this)">
                                    <i class="fas fa-copy"></i>
                                    <span class="copy-feedback d-none ms-2">
                                    <i class="fas fa-check-circle text-success"></i>
                                    <span class="ms-2">Copié</span>
                                    </span>
                                    </button>
                                 </div>
                              </td>
                              <td class="text-dark fw-semibold" title="" style="font-size: 14px;">
                                 TAssembedo A.Akim
                              </td>
                              <td>
                                 <span class="badge badge-success p-2">Directeur Technique</span>
                              </td>
                              <td>
                                 <form method="post" action="#" class="d-flex justify-content-center">
                                    <input type="hidden" value="#" name="tiduser">
                                    <select name="idroleuser" class="form-select form-select-sm me-2" id="idroleuser">
                                       <option value="1">
                                          User
                                       </option>
                                       <option value="1">
                                          Admin
                                       </option>
                                       <option value="1">
                                          S.Admin
                                       </option>
                                    </select>
                                    <button class="btn btn-sm btn-primary" name="btn-role">Valider</button>
                                 </form>
                              </td>
                              <td>
                                 <a href="#" class="btn btn-link text-danger">
                                 <i class="fa fa-times fw-bold"></i>
                                 </a>
                                 <a href="#" class="btn btn-link text-dark">
                                 <i class="fa fa-edit fw-bold"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr>
                              <td>
                                 <div class="d-flex">
                                    <a class="fw-bold text-info" href="#">
                                    DRH997UR
                                    </a>
                                    <button class="btn btn-sm ms-2" onclick="copyToClipboard('<?php echo 'DRH997UR' ?>', this)">
                                    <i class="fas fa-copy"></i>
                                    <span class="copy-feedback d-none ms-2">
                                    <i class="fas fa-check-circle text-success"></i>
                                    <span class="ms-2">Copié</span>
                                    </span>
                                    </button>
                                 </div>
                              </td>
                              <td class="text-dark fw-semibold" title="" style="font-size: 14px;">
                                 HARO Razack
                              </td>
                              <td>
                                 <span class="badge bg-success p-2">Assistant informatique</span>
                              </td>
                              <td>
                                 <form method="post" action="#" class="d-flex justify-content-center">
                                    <input type="hidden" value="#" name="tiduser">
                                    <select name="idroleuser" class="form-select form-select-sm me-2" id="idroleuser">
                                       <option value="1">
                                          Admin
                                       </option>
                                       <option value="1">
                                          User
                                       </option>
                                       <option value="1">
                                          S.Admin
                                       </option>
                                    </select>
                                    <button class="btn btn-sm btn-primary" name="btn-role">Valider</button>
                                 </form>
                              </td>
                              <td>
                                 <a href="#" class="btn btn-link text-danger">
                                 <i class="fa fa-times fw-bold"></i>
                                 </a>
                                 <a href="#" class="btn btn-link text-dark">
                                 <i class="fa fa-edit fw-bold"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr>
                              <td>
                                 <div class="d-flex">
                                    <a class="fw-bold text-info" href="#">
                                    DRH284IS
                                    </a>
                                    <button class="btn btn-sm ms-2" onclick="copyToClipboard('<?php echo 'DRH284IS' ?>', this)">
                                    <i class="fas fa-copy"></i>
                                    <span class="copy-feedback d-none ms-2">
                                    <i class="fas fa-check-circle text-success"></i>
                                    <span class="ms-2">Copié</span>
                                    </span>
                                    </button>
                                 </div>
                              </td>
                              <td class="text-dark fw-semibold" title="" style="font-size: 14px;">
                                 BEHIDI Espoir
                              </td>
                              <td>
                                 <span class="badge badge-success p-2">Assistant informatique</span>
                              </td>
                              <td>
                                 <form method="post" action="#" class="d-flex justify-content-center">
                                    <input type="hidden" value="#" name="tiduser">
                                    <select name="idroleuser" class="form-select form-select-sm me-2" id="idroleuser">
                                       <option value="1">
                                          Admin
                                       </option>
                                       <option value="1">
                                          User
                                       </option>
                                       <option value="1">
                                          S.Admin
                                       </option>
                                    </select>
                                    <button class="btn btn-sm btn-primary" name="btn-role">Valider</button>
                                 </form>
                              </td>
                              <td>
                                 <a href="#" class="btn btn-link text-danger">
                                 <i class="fa fa-times fw-bold"></i>
                                 </a>
                                 <a href="#" class="btn btn-link text-dark">
                                 <i class="fa fa-edit fw-bold"></i>
                                 </a>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>/public/admin/assets/scripts.js"></script>
