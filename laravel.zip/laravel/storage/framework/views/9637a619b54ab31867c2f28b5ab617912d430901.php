
<?php $__env->startSection('content'); ?>

<strong>Titre : </strong><?php echo e($_post->titre); ?><br>
<strong>text : </strong><?php echo e($_post->contenue); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\DEV\projets\laravel\resources\views/show.blade.php ENDPATH**/ ?>