<?php
namespace App\Controllers;
class UsersessionController extends BaseController
{
    public function login()
    {
        echo view('/usersession/layouts/header');
        echo view('/usersession/login');
        echo view('/usersession/layouts/footer');
    }

}
