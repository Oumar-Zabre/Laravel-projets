<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

define('ID', "18884BA02DA5E423B14B00DB72C18716");
// define('ID', "total2019");
define('SENDERID', "HumanP");

class SmsTools{


    /*
    $senderId : alphanumérique ne depassant pas 12 caracteres. ex: fasomobili


    $id=Id unique pour l'envois . Exemple: 1PgaJb4aDiEBgxibEagvKA8cmoPHcTAN5J
    $dnr: la liste des numeros de telephones en format international et séparé par des virgules. ex: 22678378417,22672276296
    $msg: le message à envoyer.
    */
    public static function sendSmsbusGet($phoneNumber,$msg){
        // $phoneNumber = substr($phoneNumber, 1, strlen($phoneNumber)-1);
        $smsbus= 'https://www.lesmsbus.com:7170/ines.smsbus/smsbusMt?to='.$phoneNumber.'&text='.$msg.'&id='.ID.'&from='.SENDERID."&jca=0";//'https://www.lesmsbus.com:7170/ines.smsbus/smsbusMt?'.$senderId.'&id='.$id.'&msg='.urlencode($msg).'&dnr='.$phoneNumber;
        $response=@file($smsbus);
        $res = json_encode($response);
        // echo $res;
        
        return SmsTools::getRet($res);
    }

    /*
    $senderId : alphanumérique ne depassant pas 12 caracteres. ex: fasomobili
    $id=Id unique pour l'envois . Exemple: 1PgaJb4aDiEBgxibEagvKA8cmoPHcTAN5J
    $dnr: la liste des numeros de telephones en format international et séparé par des virgules. ex: 22678378417,22672276296
    $msg: le message à envoyer.
    */
    public static function sendSmsbusPOST($phoneNumber,$msg){
        // $phoneNumber = substr($phoneNumber, 1, strlen($phoneNumber)-1);
        $ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,"https://www.lesmsbus.com:7170/ines.smsbus/smsbusMt?");
        curl_setopt($ch,CURLOPT_POST,1);
        curl_setopt($ch,CURLOPT_POSTFIELDS, "from=".SENDERID."&id=".ID."&msg=".urlencode($msg)."&dnr=".$phoneNumber."&jca=0");
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,false);
        curl_setopt($ch,CURLOPT_TIMEOUT,5);//5 seconds
        $response=curl_exec($ch);
        curl_close($ch);
        // echo $response;
        return SmsTools::getRet($response);
    }
//?id=
    public static function solde(){
       $smsbus= 'https://www.lesmsbus.com:7170/ines.smsbus/Balance?id='.ID;//'https://www.lesmsbus.com:7170/ines.smsbus/smsbusMt?'.$senderId.'&id='.$id.'&msg='.urlencode($msg).'&dnr='.$phoneNumber;
        $response=@file($smsbus);
        $res = json_encode($response);
        // echo $res;
        if (stripos($res, '|') !== false) {
            return SmsTools::getRet($res);
        } else {
            $ret['code'] = '0000';
            $ret['msg'] = $res;
        }
        if ($ret['code']=='0009') {
            Tools::sendSoldeEmpty($ret['msg']);
        }
        
        return $ret;
    }

    public static function getRet($res){
        $ret = array();
        if (stripos($res, '|') !== false) {
            $ret['code'] = substr($res, 0, 4);
            switch ($ret['code']) {
                case '0000':{ $ret['msg'] = 'OK';break;}
                case '0001':{ $ret['msg'] = 'Message vide';break;}
                case '0002':{ $ret['msg'] = 'Login/Pwd invalide';break;}
                case '0003':{ $ret['msg'] = 'Numero de téléphone invalide ou absent';break;}
                case '0004':{ $ret['Msg'] = "Id n\'existe pas";break;}
                case '0005':{ $ret["msg"] = "Erreur d'envoi";break;}
                case '0006':{ $ret["msg"] = 'Pas de route pour ce numéro';break;}
                case '0007':{ $ret["msg"] = 'Id absent';break;}
                case '0008':{ $ret["msg"] = 'Id est invalide';break;}
                case '0009':{ $ret["msg"] = 'Credit SMS insuffisant';break;}
                case '00010':{ $ret["msg"] = 'Source Erreur';break;}
                case '00011':{ $ret['msg'] = 'Operation non autorisée pour cet Id';break;}
                case '00012':{ $ret['msg'] = 'Erreur Interne au Server, veuillez réessayer';break;}
            }
        }else{
            $ret['code'] = '0000';
            $ret['msg'] = 'OK';
        }
        return $ret;
    }

    public static function accRec($msgid){
        $smsbus= 'https://www.lesmsbus.com:7170/ines.smsbus/smsState?id='.ID.'&msgId='.$msgid;
        //'https://www.lesmsbus.com:7170/ines.smsbus/smsbusMt?'.$senderId.'&id='.$id.'&msg='.urlencode($msg).'&dnr='.$phoneNumber;
        $response=@file($smsbus);
        $res = json_encode($response);
        echo $res;
        
        // return SmsTools::getRet($res);
    }
}