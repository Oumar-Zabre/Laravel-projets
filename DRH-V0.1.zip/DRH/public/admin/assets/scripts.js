
   // Fonction pour exporter en Excel
   function exportTableToExcel(tableID, filename = '') {
    var wb = XLSX.utils.table_to_book(document.getElementById(tableID), {sheet: "Sheet1"});
    var wbout = XLSX.write(wb, {bookType: 'xlsx', type: 'binary'});
   
    function s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i=0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    }
   
    var defaultFilename = filename ? filename + '.xlsx' : 'export.xlsx';
    saveAs(new Blob([s2ab(wbout)], {type: "application/octet-stream"}), defaultFilename);
   }

   function copyToClipboard(text, button) {
       navigator.clipboard.writeText(text).then(function() {
           const feedback = button.querySelector('.copy-feedback');
           feedback.classList.remove('d-none');
           
           // Hide the feedback after 2 seconds
           setTimeout(function() {
               feedback.classList.add('d-none');
           }, 2000);
       }, function(err) {
           console.error('Échec de la copie: ', err);
       });
   }
