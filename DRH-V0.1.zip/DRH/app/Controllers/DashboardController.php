<?php
namespace App\Controllers;
class DashboardController extends BaseController
{
public function index(){
  echo view('/dashboard/layouts/header');
  echo view('/dashboard/index');
  echo view('/dashboard/layouts/footer');
}


}