
<?php $__env->startSection('content'); ?>


<h1>mes articles : </h1>

<h2><?php echo e($_article); ?></h2>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\DEV\projets\laravel\resources\views/article.blade.php ENDPATH**/ ?>