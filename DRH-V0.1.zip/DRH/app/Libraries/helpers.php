<?php 
namespace App\Libraries;
class Helpers {


function compareTableaux($tableau1, $tableau2) {
    $resultat = array();
    // Parcourir le premier tableau
    foreach ($tableau1 as $element1) {
        // Parcourir le deuxième tableau
        foreach ($tableau2 as $element2) {
            // Comparer les éléments
            if ($element1 != $element2) {
                // Si les éléments sont identiques, les ajouter au tableau résultat
                $resultat[] = $element1;
            }
        }
    }

    return $resultat;
}





}?>