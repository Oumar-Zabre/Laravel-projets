<?php
namespace App\Controllers;
class UsersController extends BaseController
{
    public function index()
    {
        echo view('dashboard/layouts/header');
        echo view('dashboard/users/index');
        echo view('dashboard/layouts/footer');
    }

    
}
