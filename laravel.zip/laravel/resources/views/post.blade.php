@extends('layout.app')

@section('content')
<h1>Les posts:</h1>

@foreach($_posts as $post)
<a href="{{route('post.show', ['id'=>$post->id])}}"><h4>post {{$post->id}} : </h4></a>
<br>

@endforeach


@endsection