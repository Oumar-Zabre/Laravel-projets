<nav class="navbar navbar-expand-lg navbar-light bg-primary mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" style="color: white " href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" style="color: white" aria-current="page" href="<?php echo e(route('accueil')); ?>" style="color: white">Home</a>
        <a class="nav-link" style="color: white" href="<?php echo e(route('contact')); ?> ">Contact</a>
        <a class="nav-link" style="color: white" href="<?php echo e(route('post')); ?>">Posts</a>
       
      </div>
    </div>
  </div>
</nav><?php /**PATH C:\Users\HP\Desktop\DEV\projets\laravel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>