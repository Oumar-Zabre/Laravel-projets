<?php 

	/*
	*	Auteur  : COMPAORE MOUSTAPHA
	*	URL     :	http://www.comptechnoafrique.com/demos/moustacompa
	*	Version : 3.0
	*   Update date : 16/02/2022 
	*/

	define('ENVIRONMENT', isset($_SERVER['CI_ENV']) ? $_SERVER['CI_ENV'] : 'development');
	
	$db['default'] = array(
		'port'	=> '3306',
		'hostname' => 'localhost',
		'username' => 'root',
		'password' => '',
		'database' => 'logistec',
		'dbdriver' => 'mysql',		
	);

	$exclude_tab = array('eated_by', 'dated_by', 'leted_by');

	//include_once 'config/database.php';

	$modelPath = __DIR__.'/models';
	$entityPath = __DIR__.'/Entities';

	$driver=$db['default']['dbdriver'];
	$host=$db['default']['hostname'];
	$dbname=$db['default']['database'];
	$user=$db['default']['username'];
	$pass=$db['default']['password'];
	$port=$db['default']['port'];
	$connexion = new PDO($driver.':host='.$host.';dbname='.$dbname.';port='.$port,$user,$pass);

	if($connexion){
		echo 'Connected to DB.';
		$nbTables = 0;
		$rnb=$connexion->query("select count(*) as 'nb' from information_schema.tables where table_schema = '".$dbname."'");
		while ($lg = $rnb->fetch(PDO::FETCH_ASSOC)) {   
			$nbTables = $lg['nb'];
		}

		$requete="SHOW TABLES";
		$resultat=$connexion->query($requete);
		$i=1;
		while ($ligne = $resultat->fetch(PDO::FETCH_ASSOC)) {   
			$prim = '';
			$className = $ligne['Tables_in_'.$dbname];
			//first letter in upper 
			$className=strtoupper(substr($className, 0, 1)).substr($className, 1, strlen($className)-1);
			echo '-----------------------------------
			'.$i.'/'.$nbTables.' - Table '.$className.'
			';
			$entityFilename = $entityPath.'/'.$className.'.php';
			$modelFilename = $modelPath.'/Mod'.$className.'.php';
		   	$entfile = fopen( $entityFilename, "w+" );
		   	$modfile = fopen( $modelFilename, "w+" );
		   	if( $entfile == false) {
		      echo ( "Error in opening entity file" );
		      exit();
		   	}
		   	if( $entfile == false) {
		      echo ( "Error in opening model file" );
		      exit();
		   	}
			$requete='DESC '.$ligne['Tables_in_'.$dbname];
			$res2=$connexion->query($requete);

			//creating files
			fwrite( $entfile, "<?php \n");
			fwrite( $modfile, "<?php \n");

			//hearder
			fwrite( $entfile, "namespace App\Entities;\n");
			fwrite( $entfile, "use CodeIgniter\Entity\Entity;\n");
			fwrite( $entfile, "use App\Models\Mod".$className.";\n");
			fwrite( $modfile, "namespace App\Models;\n");
			fwrite( $modfile, "use CodeIgniter\Model;\n");
			fwrite( $modfile, "use App\Entities\\".$className.";\n\n");
			$lProp = $res2->fetchAll(PDO::FETCH_ASSOC);
			foreach ($lProp as $prop) {
				if ($prop['Key']=="PRI") {
					$prim = $prop['Field'];
				}
				if ($prop['Key']=='MUL') {
					$fkCls=strtoupper(substr($prop['Field'], 2, 1)).substr($prop['Field'], 3, strlen($prop['Field'])-1);
					if (!in_array(strtolower($fkCls), $exclude_tab)) {
						fwrite( $entfile, "use App\Models\Mod".$fkCls.";\n");
					}
				}
			}
			
			$sqlFK = "select TABLE_NAME from`INFORMATION_SCHEMA`.`COLUMNS` where COLUMN_NAME = '".$prim."' and TABLE_SCHEMA = '".$dbname."' and TABLE_NAME != '".$ligne['Tables_in_'.$dbname]."'";
			
			$resFk=$connexion->query($sqlFK);
			$lstFk = $resFk->fetchAll(PDO::FETCH_ASSOC);
			foreach ($lstFk as $lfk) {   
				$fkName=strtoupper(substr($lfk['TABLE_NAME'], 0, 1)).substr($lfk['TABLE_NAME'], 1, strlen($lfk['TABLE_NAME'])-1);
				fwrite( $entfile, "use App\Models\Mod".$fkName.";\n");
			}


			fwrite( $entfile, "\n");
			// class name
			fwrite( $entfile, "class ".$className." extends Entity {\n\n");
			fwrite( $modfile, "class Mod".$className." extends Model {\n\n");

			//Model protected properties
			fwrite( $modfile, "\t".'protected $'."DBGroup  = 'default';\n");
			fwrite( $modfile, "\t".'protected $'."table= '".$ligne['Tables_in_'.$dbname]."';\n");
			
			fwrite( $modfile, "\t".'protected $'."returnType   = 'App\Entities\\".$className."';\n");
			fwrite( $modfile, "\t".'protected $'."useSoftDeletes   = true;\n");
			fwrite( $modfile, "\t".'protected $'."protectFields= true;\n");
			fwrite( $modfile, "\t".'protected $'."db;\n\n");
			fwrite( $modfile, "\t".'protected $'."useTimestamps= true;\n");
			fwrite( $modfile, "\t".'protected $'."dateFormat   = 'datetime';\n");
			fwrite( $modfile, "\t".'protected $'."createdField = 'createdAt';\n");
			fwrite( $modfile, "\t".'protected $'."updatedField = 'updatedAt';\n");
			fwrite( $modfile, "\t".'protected $'."deletedField = 'deletedAt';\n\n");

			fwrite( $modfile, "\t".'protected $'."allowedFields = [\n");
			//properties
		   	
			foreach ($lProp as $prop) {
				fwrite( $modfile, "\t\t".'"'.$prop['Field'].'"'.",\n");
			}
			fwrite( $modfile, "\t];\n");
			fwrite( $modfile, "\t".'protected $'."primaryKey   = '".$prim."';\n\n");

			//constructor
			/*
			fwrite( $modfile, "\tpublic function __construct(){\n");
				fwrite($modfile, "\t\t");
				fwrite( $modfile, '$this->table = "'.$ligne['Tables_in_'.$dbname].'";');
			fwrite( $modfile, "\n\t}\n\n");
		   	*/
			//getters and setters
			foreach ($lProp as $prop) {
				//getters
				$propName=strtoupper(substr($prop['Field'], 0, 1)).substr($prop['Field'], 1, strlen($prop['Field'])-1);
				fwrite( $entfile, "\tpublic function get".$propName."(){\n");
					fwrite( $entfile, "\t\t".'return $this->attributes['."'".$prop['Field']."']".';'."\n");
				fwrite( $entfile, "\t}\n\n");

				//setters
				fwrite( $entfile, "\tpublic function set".$propName."($".$prop['Field']."){\n");
					// fwrite( $file, );
					fwrite( $entfile, "\t\t".'$this->attributes['."'".$prop['Field']."']".'=$'.$prop['Field'].';'."\n");
				fwrite( $entfile, "\t}\n\n");
				 // var_dump($line2);

				//check if it is a fk
				if ($prop['Key']=='MUL') {
					$fkCls=strtoupper(substr($prop['Field'], 2, 1)).substr($prop['Field'], 3, strlen($prop['Field'])-1);
					if (!in_array(strtolower($fkCls), $exclude_tab)){
						fwrite( $entfile, "\tpublic function get".$fkCls."(){\n");

						fwrite( $entfile, "\t\t".'if (empty($this->'.$prop['Field'].')) return null;'."\n");
						fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkCls."();\n");
						fwrite( $entfile, "\t\t".'return $obj->findPk($this->'.$prop['Field'].');'."\n");
						fwrite( $entfile, "\t}\n\n");
					}
				}
			}

			//getting N-1 or N-N links
			foreach ($lstFk as $lfk) {   
				$fkName=strtoupper(substr($lfk['TABLE_NAME'], 0, 1)).substr($lfk['TABLE_NAME'], 1, strlen($lfk['TABLE_NAME'])-1);
				fwrite( $entfile, "\tpublic function get".$fkName."s(){\n");
				fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkName."();\n");
				fwrite( $entfile, "\t\t".'return $obj->where1(\''.$prim.' = \'. $this->'.$prim.');'."\n");
				fwrite( $entfile, "\t}\n\n");
			}

			//clearing
			foreach ($lstFk as $lfk) {   
				$fkName=strtoupper(substr($lfk['TABLE_NAME'], 0, 1)).substr($lfk['TABLE_NAME'], 1, strlen($lfk['TABLE_NAME'])-1);
				fwrite( $entfile, "\tpublic function clear".$fkName."s(){\n");
				fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkName.'();'."\n");
				fwrite( $entfile, "\t\t".'return $obj->where(\''.$prim.' = \'. $this->'.$prim.')->delete();'."\n");
				fwrite( $entfile, "\t}\n\n");
			}

			//getSome
			foreach ($lstFk as $lfk) {
				$fkName=strtoupper(substr($lfk['TABLE_NAME'], 0, 1)).substr($lfk['TABLE_NAME'], 1, strlen($lfk['TABLE_NAME'])-1);
				fwrite( $entfile, "\tpublic function getSome".$fkName."s(".'$nb'."){\n");
				fwrite( $entfile, "\t\t".'$obj = new Mod'.$fkName.'();'."\n");
				fwrite( $entfile, "\t\t".'return $obj->whereSome(\''.$prim.' = \'. $this->'.$prim.', $nb);'."\n");
				fwrite( $entfile, "\t}\n\n");
			}

			//getFirst
			foreach ($lstFk as $lfk) {
				$fkName=strtoupper(substr($lfk['TABLE_NAME'], 0, 1)).substr($lfk['TABLE_NAME'], 1, strlen($lfk['TABLE_NAME'])-1);
				fwrite( $entfile, "\tpublic function getFirst".$fkName."(){\n");
				fwrite( $entfile, "\t\t".'$lst = $this->get'.$fkName.'s();'."\n");
				fwrite( $entfile, "\t\t".'$n = count($lst);'."\n");
				fwrite( $entfile, "\t\t".'$rep = ($n==0) ? null : $lst[0] ;'."\n");
				fwrite( $entfile, "\t}\n\n");
			}

			//getLast
			foreach ($lstFk as $lfk) {  
				$fkName=strtoupper(substr($lfk['TABLE_NAME'], 0, 1)).substr($lfk['TABLE_NAME'], 1, strlen($lfk['TABLE_NAME'])-1);
				fwrite( $entfile, "\tpublic function getLast".$fkName."(){\n");
				fwrite( $entfile, "\t\t".'$lst = $this->get'.$fkName.'s();'."\n");
				fwrite( $entfile, "\t\t".'$n = count($lst);'."\n");
				fwrite( $entfile, "\t\t".'$rep = ($n==0) ? null : $lst[$n-1] ;'."\n");
				fwrite( $entfile, "\t}\n\n");
			}


			//getData
			fwrite( $entfile, "\tpublic function getData(){\n");
				fwrite( $entfile, "\t\t".'return $this->attributes;'."\n");
			fwrite( $entfile, "\t}\n\n");

			//findPk
			fwrite( $modfile, "\tpublic function findPk(".'$id'."){\n");
				fwrite( $modfile, "\t\t".'$ret = $this->find($id);'."\n");
				fwrite( $modfile, "\t\t".'if(empty($ret)) return null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($ret)) return $ret[0];'."\n");
				fwrite( $modfile, "\t\t".'return $ret;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//getFirst
			fwrite( $modfile, "\tpublic function getFirst(){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($this->primaryKey,"asc")->findAll(1,0);'."\n");
	        fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//getLast
			fwrite( $modfile, "\tpublic function getLast(){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($this->primaryKey,"desc")->findAll(1,0);'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");
			
			//findSome
			fwrite( $modfile, "\tpublic function findSome(".'$nb'."){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($this->primaryKey,"desc")->findAll($nb,0);'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//findAllOrder
			fwrite( $modfile, "\tpublic function findAllOrder(".'$col, $type'."){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($col,$type)->findAll();'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");


			//findOrder
			fwrite( $modfile, "\tpublic function findOrder(".'$col, $type, $nb'."){\n");
			fwrite( $modfile, "\t\t".'$obj = $this->orderby($col,$type)->findAll($nb,0);'."\n");
		    fwrite( $modfile, "\t\t".'return $obj;'."\n");
			fwrite( $modfile, "\t}\n\n");

			//where
			fwrite( $modfile, "\tpublic function where1(".'$params'."){\n");
				fwrite( $modfile, "\t\t".'$lst = null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$keys = array_keys($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$vals = array_values($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($keys[0], $vals[0]);'."\n");
		        fwrite( $modfile, "\t\t\t".'for ($i=1; $i < count($keys); $i++) { '."\n");
		        fwrite( $modfile, "\t\t\t\t".'$lst = $lst->where($keys[$i], $vals[$i]);'."\n");
		        fwrite( $modfile, "\t\t\t".'}'."\n");
		        fwrite( $modfile, "\t\t".'} elseif (is_numeric($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($this->primaryKey,$params);'."\n");
		        fwrite( $modfile, "\t\t".'} else{'."\n");
		        fwrite( $modfile, "\t\t\t".'$t = explode("=",$params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where(trim($t[0]),trim($t[1]));'."\n");
		        fwrite( $modfile, "\t\t".'}'."\n");
				fwrite( $modfile, "\t\t".'return $lst->findAll();'."\n");
			fwrite( $modfile, "\t}\n\n");

			//whereOrder
			fwrite( $modfile, "\tpublic function whereOrder(".'$where, $col, $type, $nb'."){\n");
				fwrite( $modfile, "\t\t".'$lst = null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$keys = array_keys($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$vals = array_values($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($keys[0], $vals[0]);'."\n");
		        fwrite( $modfile, "\t\t\t".'for ($i=1; $i < count($keys); $i++) { '."\n");
		        fwrite( $modfile, "\t\t\t\t".'$lst = $lst->where($keys[$i], $vals[$i]);'."\n");
		        fwrite( $modfile, "\t\t\t".'}'."\n");
		        fwrite( $modfile, "\t\t".'} elseif (is_numeric($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($this->primaryKey,$params);'."\n");
		        fwrite( $modfile, "\t\t".'} else{'."\n");
		        fwrite( $modfile, "\t\t\t".'$t = explode("=",$params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where(trim($t[0]),trim($t[1]));'."\n");
		        fwrite( $modfile, "\t\t".'}'."\n");
				fwrite( $modfile, "\t\t".'return $lst->orderBy($col, $type)->findAll($nb,0);'."\n");
			fwrite( $modfile, "\t}\n\n");

			//whereSome
			fwrite( $modfile, "\tpublic function whereSome(".'$params, $nb'."){\n");
				fwrite( $modfile, "\t\t".'$lst = null;'."\n");
				fwrite( $modfile, "\t\t".'if (is_array($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$keys = array_keys($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$vals = array_values($params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($keys[0], $vals[0]);'."\n");
		        fwrite( $modfile, "\t\t\t".'for ($i=1; $i < count($keys); $i++) { '."\n");
		        fwrite( $modfile, "\t\t\t\t".'$lst = $lst->where($keys[$i], $vals[$i]);'."\n");
		        fwrite( $modfile, "\t\t\t".'}'."\n");
		        fwrite( $modfile, "\t\t".'} elseif (is_numeric($params)) {'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where($this->primaryKey,$params);'."\n");
		        fwrite( $modfile, "\t\t".'} else{'."\n");
		        fwrite( $modfile, "\t\t\t".'$t = explode("=",$params);'."\n");
		        fwrite( $modfile, "\t\t\t".'$lst = $this->where(trim($t[0]),trim($t[1]));'."\n");
		        fwrite( $modfile, "\t\t".'}'."\n");
				fwrite( $modfile, "\t\t".'return $lst->findAll($nb,0);'."\n");
			fwrite( $modfile, "\t}\n\n");

			//save
			fwrite( $entfile, "\tpublic function save(){\n");
			fwrite( $entfile, "\t\t".'$model = new Mod'.$className.'();'."\n");
	        fwrite( $entfile, "\t\t".'$data = $this->getData();'."\n");
	        fwrite( $entfile, "\t\t".'return $model->saveData($data);'."\n");
			fwrite( $entfile, "\t}\n\n");

			//saveData
			fwrite( $modfile, "\t".'public function saveData($data){'."\n");
		    fwrite( $modfile, "\t\t".'if (!array_key_exists($this->primaryKey, $data)) {'."\n");
		    fwrite( $modfile, "\t\t\t".'$ret = $this->insert($data);'."\n");
		    fwrite( $modfile, "\t\t\t".'return $ret;'."\n");
		    fwrite( $modfile, "\t\t".'}else{'."\n");
		    fwrite( $modfile, "\t\t\t".'$data[$this->updatedField]=date("Y-m-d H:i:s");'."\n");
		    fwrite( $modfile, "\t\t\t".'$ret = $this->where([$this->primaryKey => $data[$this->primaryKey]])->set($data)->update();'."\n");
		    fwrite( $modfile, "\t\t\t".'return $ret;'."\n");
		    fwrite( $modfile, "\t\t}\n");
			fwrite( $modfile, "\t}\n\n");
			
			$i++;
			//end of class
			fwrite( $entfile, "}");
		   	fclose( $entfile );
			fwrite( $modfile, "}");
		   	fclose( $modfile);
		}

			echo "----------------------------------- \nModel generated successfuly";
	}else{
		echo 'Error Connection to DB';
	}

?>