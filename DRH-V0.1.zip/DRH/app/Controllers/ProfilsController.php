<?php
namespace App\Controllers;
class ProfilsController extends BaseController
{

}
