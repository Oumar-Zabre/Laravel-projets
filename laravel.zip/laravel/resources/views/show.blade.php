@extends('layout.app')
@section('content')

<strong>Titre : </strong>{{$_post->titre}}<br>
<strong>text : </strong>{{$_post->contenue}}

@endsection